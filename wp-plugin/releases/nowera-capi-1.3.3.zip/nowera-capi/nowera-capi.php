<?php
/**
 * Plugin Name:  Nowera CAPI
 * Description:  Posiela serverové eventy z WooCommerce do Nowera Gateway (Meta CAPI + GA4) a zdieľa event_id s prehliadačovou vetvou.
 * Version:      1.3.3
 * Author:       Nowera
 * License:      GPL-2.0-or-later
 * Requires at least: 6.0
 * Requires PHP: 8.0
 * Update URI:   https://signals.nwra.sk/wp/nowera-capi
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const NOWERA_CAPI_OPTION  = 'nowera_capi_settings';
const NOWERA_CAPI_VERSION = '1.3.3';

/**
 * Ed25519 public keys whose signature an update must carry. The private key
 * never leaves the release machine, so neither the gateway nor the repository
 * can push code to a site. Several keys allow rotating to a new one.
 */
const NOWERA_CAPI_RELEASE_KEYS = array( 'EkZtQ4CBqMWrwbFSAl5eS11cGNUku9GfX3cVczn9qZc=' );

/** Cloudflare's edge ranges: only from these is CF-Connecting-IP believed. */
const NOWERA_CAPI_CLOUDFLARE = array(
	'173.245.48.0/20', '103.21.244.0/22', '103.22.200.0/22', '103.31.4.0/22',
	'141.101.64.0/18', '108.162.192.0/18', '190.93.240.0/20', '188.114.96.0/20',
	'197.234.240.0/22', '198.41.128.0/17', '162.158.0.0/15', '104.16.0.0/13',
	'104.24.0.0/14', '172.64.0.0/13', '131.0.72.0/22',
	'2400:cb00::/32', '2606:4700::/32', '2803:f800::/32', '2405:b500::/32',
	'2405:8100::/32', '2a06:98c0::/29', '2c0f:f248::/32',
);

/** Contact fields kept, hashed, in the _nwr_ud cookie for returning customers. */
const NOWERA_CAPI_STORED_KEYS = array( 'em', 'ph', 'fn', 'ln', 'ct', 'st', 'zp', 'country' );

/**
 * Calling codes for the countries our shops sell to. Meta matches a phone number
 * only in its full international form, so one typed the national way
 * (0905 123 456) needs the country's code in front of it.
 */
const NOWERA_CAPI_CALLING_CODES = array(
	'SK' => '421', 'CZ' => '420', 'PL' => '48', 'HU' => '36', 'AT' => '43', 'DE' => '49',
	'CH' => '41', 'SI' => '386', 'HR' => '385', 'RO' => '40', 'UA' => '380', 'IT' => '39',
	'FR' => '33', 'GB' => '44', 'IE' => '353', 'NL' => '31', 'BE' => '32', 'ES' => '34',
);

/** What a national number starts with and the international form drops. Default '0'. */
const NOWERA_CAPI_TRUNK_PREFIXES = array( 'HU' => '06', 'IT' => '', 'ES' => '' );

/**
 * What a single page of a custom post type can be in a Meta catalog, as the
 * content_type its pixel events carry: products, a real-estate (home listing)
 * catalog or a vehicle catalog.
 */
const NOWERA_CAPI_CPT_CONTENT_TYPES = array(
	'product'      => 'product (katalóg produktov)',
	'home_listing' => 'home_listing (nehnuteľnosti)',
	'vehicle'      => 'vehicle (vozidlá)',
);

/* -------------------------------------------------------------------------
 * Settings
 * ---------------------------------------------------------------------- */

function nowera_capi_settings(): array {
	$defaults = array(
		'collector_host' => '',
		'ingest_secret'  => '',
		'load_script'    => 1,
		'consent_mode'   => 'none',
		'consent_prefix' => 'cmplz_',
		'auto_update'    => 1,
		'ga4_tag'        => '',
		'forms'          => array(),
		'cpt_catalog'    => array(),
	);
	return wp_parse_args( get_option( NOWERA_CAPI_OPTION, array() ), $defaults );
}

/** Which forms count, as form key ("plugin:id") => lead | newsletter. */
function nowera_capi_clean_forms( $input ): array {
	$out = array();
	foreach ( is_array( $input ) ? $input : array() as $key => $role ) {
		if ( preg_match( '/^[a-z0-9]{2,20}:[A-Za-z0-9_-]{1,64}$/', (string) $key ) && in_array( $role, array( 'lead', 'newsletter' ), true ) ) {
			$out[ (string) $key ] = $role;
		}
	}
	return $out;
}

/**
 * Post types whose single pages can be reported as catalog items: the site's
 * own public types. WordPress's built-in ones are no catalog, WooCommerce
 * products have their own handling, and page-builder templates are no content.
 */
function nowera_capi_cpt_choices(): array {
	$out = array();
	foreach ( get_post_types( array( 'public' => true, '_builtin' => false ), 'objects' ) as $name => $type ) {
		if ( in_array( $name, array( 'product', 'product_variation', 'bricks_template', 'elementor_library' ), true ) ) {
			continue;
		}
		$out[ $name ] = wp_strip_all_tags( (string) ( $type->labels->name ?? $name ) );
	}
	return $out;
}

/** Which post types count as a catalog, as post type => Meta content_type. */
function nowera_capi_clean_cpt_catalog( $input ): array {
	$out     = array();
	$choices = nowera_capi_cpt_choices();
	foreach ( is_array( $input ) ? $input : array() as $type => $content_type ) {
		if ( isset( $choices[ (string) $type ] ) && is_string( $content_type ) && isset( NOWERA_CAPI_CPT_CONTENT_TYPES[ $content_type ] ) ) {
			$out[ (string) $type ] = $content_type;
		}
	}
	return $out;
}

/** A pairing code from the gateway's dashboard: nwr1.<base64url of {"h": host, "k": key}>. */
function nowera_capi_read_pairing( string $code ): ?array {
	if ( ! preg_match( '/^nwr1\.([A-Za-z0-9_-]+)$/', trim( $code ), $m ) ) {
		return null;
	}
	$data = json_decode( (string) base64_decode( strtr( $m[1], '-_', '+/' ) ), true );
	if ( ! is_array( $data ) || ! is_string( $data['h'] ?? null ) || ! is_string( $data['k'] ?? null ) ) {
		return null;
	}
	if ( ! preg_match( '/^[a-z0-9-]+(\.[a-z0-9-]+)+$/i', $data['h'] ) || ! preg_match( '/^[0-9a-f]{64}$/i', $data['k'] ) ) {
		return null;
	}
	return array( 'host' => strtolower( $data['h'] ), 'key' => $data['k'] );
}

// WooCommerce: the plugin reads orders only through the order API, and hooks the block checkout too.
add_action( 'before_woocommerce_init', function () {
	if ( class_exists( \Automattic\WooCommerce\Utilities\FeaturesUtil::class ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', __FILE__, true );
	}
} );

add_action( 'admin_menu', function () {
	add_options_page( 'Nowera CAPI', 'Nowera CAPI', 'manage_options', 'nowera-capi', 'nowera_capi_render_settings' );
} );

add_action( 'admin_init', function () {
	register_setting( 'nowera_capi', NOWERA_CAPI_OPTION, array(
		'sanitize_callback' => function ( $input ) {
			$current = nowera_capi_settings();
			$host    = strtolower( preg_replace( '#^https?://|/.*$#i', '', sanitize_text_field( $input['collector_host'] ?? '' ) ) );
			// The key is never printed back into the form: an empty field keeps it.
			$key = sanitize_text_field( $input['ingest_secret'] ?? '' );
			$key = '' === $key ? $current['ingest_secret'] : $key;
			if ( ! empty( $input['pairing_code'] ) ) {
				$pair = nowera_capi_read_pairing( (string) $input['pairing_code'] );
				if ( $pair ) {
					$host = $pair['host'];
					$key  = $pair['key'];
				} else {
					add_settings_error( NOWERA_CAPI_OPTION, 'pairing', 'Párovací kód nie je platný — skopírujte ho z administrácie gatewaya celý.' );
				}
			}
			return array(
				'collector_host' => $host,
				'ingest_secret'  => $key,
				'auto_update'    => empty( $input['auto_update'] ) ? 0 : 1,
				'load_script'    => empty( $input['load_script'] ) ? 0 : 1,
				'consent_mode'   => in_array( $input['consent_mode'] ?? 'none', array( 'none', 'faz', 'cookiescript', 'complianz', 'custom' ), true )
					? $input['consent_mode']
					: 'none',
				'consent_prefix' => preg_replace( '/[^a-zA-Z0-9_\-]/', '', $input['consent_prefix'] ?? 'cmplz_' ) ?: 'cmplz_',
				'forms'          => nowera_capi_clean_forms( $input['forms'] ?? array() ),
				'cpt_catalog'    => nowera_capi_clean_cpt_catalog( $input['cpt_catalog'] ?? array() ),
				'ga4_tag'        => preg_match( '/^G-[A-Z0-9]{4,20}$/', strtoupper( trim( (string) ( $input['ga4_tag'] ?? '' ) ) ) )
					? strtoupper( trim( (string) $input['ga4_tag'] ) )
					: '',
			);
		},
	) );
} );

function nowera_capi_render_settings(): void {
	$s      = nowera_capi_settings();
	$status = get_option( 'nowera_capi_status', array() );
	$status = is_array( $status ) ? $status : array();
	$test   = get_transient( 'nowera_capi_test_' . get_current_user_id() );
	if ( $test ) {
		delete_transient( 'nowera_capi_test_' . get_current_user_id() );
	}
	$ago = function ( $t ) {
		return $t ? sprintf( 'pred %s', human_time_diff( (int) $t ) ) : '—';
	};
	?>
	<div class="wrap">
		<h1>Nowera CAPI <span style="font-size:13px;color:#646970;font-weight:400"><?php echo esc_html( NOWERA_CAPI_VERSION ); ?></span></h1>
		<?php if ( is_array( $test ) ) : ?>
			<div class="notice notice-<?php echo $test['ok'] ? 'success' : 'error'; ?>"><p><?php echo esc_html( $test['message'] ); ?></p></div>
		<?php endif; ?>
		<?php if ( $s['collector_host'] && $s['ingest_secret'] ) : ?>
			<p>
				<?php if ( ! empty( $status['failing'] ) ) : ?>
					<strong style="color:#b32d2e">Posledné odoslanie zlyhalo</strong> <?php echo esc_html( $ago( $status['error_at'] ?? 0 ) ); ?>:
					<code><?php echo esc_html( $status['error'] ?? '' ); ?></code>
				<?php else : ?>
					Posledné doručenie do gatewaya: <strong><?php echo esc_html( $ago( $status['ok_at'] ?? 0 ) ); ?></strong>
				<?php endif; ?>
			</p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin:0 0 12px">
				<input type="hidden" name="action" value="nowera_capi_test">
				<?php wp_nonce_field( 'nowera_capi_test' ); ?>
				<?php submit_button( 'Otestovať spojenie', 'secondary', 'submit', false ); ?>
				<span class="description">Overí, že gateway odpovedá a prijme podpis tohto webu. Nevytvorí žiadny event.</span>
			</form>
		<?php endif; ?>
		<form method="post" action="options.php">
			<?php settings_fields( 'nowera_capi' ); ?>
			<table class="form-table" role="presentation">
				<tr>
					<th scope="row"><label for="nwr_pairing">Párovací kód</label></th>
					<td>
						<input id="nwr_pairing" class="large-text code" type="text" name="<?php echo esc_attr( NOWERA_CAPI_OPTION ); ?>[pairing_code]"
						       value="" placeholder="nwr1.…" autocomplete="off">
						<p class="description">Z administrácie gatewaya (Nový klient alebo Nastavenia → Vygenerovať kľúč). Vyplní collector host aj kľúč naraz.</p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="nwr_host">Collector host</label></th>
					<td>
						<input id="nwr_host" class="regular-text code" type="text" name="<?php echo esc_attr( NOWERA_CAPI_OPTION ); ?>[collector_host]"
						       value="<?php echo esc_attr( $s['collector_host'] ); ?>" placeholder="t.klient.sk">
						<p class="description">Bez <code>https://</code>. Musí sedieť s hostom nastaveným v Gateway administrácii.</p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="nwr_secret">Kľúč</label></th>
					<td>
						<input id="nwr_secret" class="regular-text code" type="password" name="<?php echo esc_attr( NOWERA_CAPI_OPTION ); ?>[ingest_secret]"
						       value="" autocomplete="new-password" placeholder="<?php echo $s['ingest_secret'] ? esc_attr( 'uložený — nechajte prázdne' ) : ''; ?>">
						<p class="description">Kľúč tohto webu z administrácie gatewaya. Podpisuje serverové eventy. Prázdne pole ponechá uložený kľúč.</p>
					</td>
				</tr>
				<tr>
					<th scope="row">Aktualizácie</th>
					<td>
						<label>
							<input type="checkbox" name="<?php echo esc_attr( NOWERA_CAPI_OPTION ); ?>[auto_update]" value="1" <?php checked( $s['auto_update'] ); ?>>
							Inštalovať nové verzie automaticky
						</label>
						<p class="description">Vydania prichádzajú z gatewaya a inštalujú sa, len ak ich podpis sedí s kľúčom zabudovaným v plugine.</p>
					</td>
				</tr>
				<tr>
					<th scope="row">Loader</th>
					<td>
						<label>
							<input type="checkbox" name="<?php echo esc_attr( NOWERA_CAPI_OPTION ); ?>[load_script]" value="1" <?php checked( $s['load_script'] ); ?>>
							Vložiť <code>px.js</code> do hlavičky
						</label>
						<p class="description">Vypnite, ak loader vkladáte cez GTM alebo ručne.</p>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="nwr_consent">Súhlas s cookies</label></th>
					<td>
						<select id="nwr_consent" name="<?php echo esc_attr( NOWERA_CAPI_OPTION ); ?>[consent_mode]">
							<option value="none" <?php selected( $s['consent_mode'], 'none' ); ?>>Nekontrolovať (meria sa vždy)</option>
							<option value="faz" <?php selected( $s['consent_mode'], 'faz' ); ?>>FAZ Cookie Manager</option>
							<option value="cookiescript" <?php selected( $s['consent_mode'], 'cookiescript' ); ?>>CookieScript</option>
							<option value="complianz" <?php selected( $s['consent_mode'], 'complianz' ); ?>>Complianz</option>
							<option value="custom" <?php selected( $s['consent_mode'], 'custom' ); ?>>Iný nástroj (cookie s prefixom)</option>
						</select>
						<p class="description">
							Meta dostane eventy len so súhlasom <strong>marketing</strong>, GA4 so súhlasom <strong>statistics</strong>
							(vo FAZ kategórie <code>marketing</code> a <code>analytics</code>, v CookieScripte <code>targeting</code> a <code>performance</code>).
							Pri inom nástroji zavolajte po rozhodnutí návštevníka <code>nwr('consent')</code>.
						</p>
					</td>
				</tr>
				<?php // Read only for Complianz (without the WP Consent API) and another tool; FAZ and CookieScript have their own cookies. ?>
				<tr id="nwr_prefix_row" <?php echo in_array( $s['consent_mode'], array( 'complianz', 'custom' ), true ) ? '' : 'style="display:none"'; ?>>
					<th scope="row"><label for="nwr_prefix">Prefix súhlasových cookies</label></th>
					<td>
						<input id="nwr_prefix" class="regular-text code" type="text" name="<?php echo esc_attr( NOWERA_CAPI_OPTION ); ?>[consent_prefix]"
						       value="<?php echo esc_attr( $s['consent_prefix'] ); ?>">
						<p class="description">
							Platí len pre Complianz a „Iný nástroj (cookie s prefixom)“; FAZ a CookieScript ho nepoužívajú.
							Complianz predvolene <code>cmplz_</code> — cookie <code>cmplz_marketing=allow</code>.
						</p>
						<script>
						( function () {
							var mode = document.getElementById( 'nwr_consent' ), row = document.getElementById( 'nwr_prefix_row' );
							if ( ! mode || ! row ) return;
							// Hidden, the field is still sent, so the stored prefix stays.
							mode.addEventListener( 'change', function () {
								row.style.display = ( mode.value === 'complianz' || mode.value === 'custom' ) ? '' : 'none';
							} );
						} )();
						</script>
					</td>
				</tr>
				<tr>
					<th scope="row">Formuláre</th>
					<td>
						<?php
						$seen  = get_option( 'nowera_capi_forms_seen', array() );
						$seen  = is_array( $seen ) ? $seen : array();
						$forms = is_array( $s['forms'] ) ? $s['forms'] : array();
						foreach ( array_keys( $forms ) as $k ) {
							$seen[ $k ] = $seen[ $k ] ?? array( 'name' => $k, 'at' => 0 );
						}
						if ( ! $seen ) :
							?>
							<p class="description">Formuláre sa tu zobrazia, keď ich návštevník prvýkrát odošle (Contact Form 7, Forminator, Elementor Pro, WPForms, Fluent Forms, Gravity Forms, Bricks s akciou „Custom“, Bricksforge Pro Forms).</p>
						<?php else : ?>
							<table class="widefat striped" style="max-width:640px"><tbody>
							<?php foreach ( $seen as $k => $f ) : ?>
								<tr><td><?php echo esc_html( $f['name'] ?: $k ); ?> <code><?php echo esc_html( $k ); ?></code></td>
									<td><select name="<?php echo esc_attr( NOWERA_CAPI_OPTION ); ?>[forms][<?php echo esc_attr( $k ); ?>]">
										<option value="">Nepočítať</option>
										<option value="lead" <?php selected( $forms[ $k ] ?? '', 'lead' ); ?>>Dopyt (Lead)</option>
										<option value="newsletter" <?php selected( $forms[ $k ] ?? '', 'newsletter' ); ?>>Newsletter (Lead)</option>
									</select></td></tr>
							<?php endforeach; ?>
							</tbody></table>
							<p class="description">Odoslaný formulár ide do Mety ako Lead a do GA4 ako generate_lead, s druhom v <code>content_category</code>.</p>
						<?php endif; ?>
					</td>
				</tr>
				<tr>
					<th scope="row">Katalóg z vlastného typu obsahu</th>
					<td>
						<?php
						$choices = nowera_capi_cpt_choices();
						$catalog = is_array( $s['cpt_catalog'] ) ? $s['cpt_catalog'] : array();
						if ( ! $choices ) :
							?>
							<p class="description">Web nemá žiadny verejný vlastný typ obsahu (napr. nehnuteľnosti, vozidlá).</p>
						<?php else : ?>
							<table class="widefat striped" style="max-width:640px"><tbody>
							<?php foreach ( $choices as $type => $label ) : ?>
								<tr><td><?php echo esc_html( $label ); ?> <code><?php echo esc_html( $type ); ?></code></td>
									<td><select name="<?php echo esc_attr( NOWERA_CAPI_OPTION ); ?>[cpt_catalog][<?php echo esc_attr( $type ); ?>]">
										<option value="">Nemerať</option>
										<?php foreach ( NOWERA_CAPI_CPT_CONTENT_TYPES as $value => $name ) : ?>
											<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $catalog[ $type ] ?? '', $value ); ?>>ViewContent – <?php echo esc_html( $name ); ?></option>
										<?php endforeach; ?>
									</select></td></tr>
							<?php endforeach; ?>
							</tbody></table>
							<p class="description">
								Zobrazenie jedného záznamu vybraného typu ide do Mety ako ViewContent a do GA4 ako view_item.
								<code>content_ids</code> je ID príspevku (to isté ID musí mať záznam v katalógovom feede), <code>content_type</code> podľa výberu.
								Cenu a kategóriu môže doplniť filter <code>nowera_capi_cpt_item</code>.
							</p>
						<?php endif; ?>
					</td>
				</tr>
				<tr>
					<th scope="row"><label for="nwr_ga4_tag">Google tag (GA4)</label></th>
					<td>
						<input id="nwr_ga4_tag" class="regular-text code" type="text" name="<?php echo esc_attr( NOWERA_CAPI_OPTION ); ?>[ga4_tag]"
						       value="<?php echo esc_attr( $s['ga4_tag'] ); ?>" placeholder="G-XXXXXXXXXX">
						<p class="description">
							Vloží do hlavičky len <code>gtag('config')</code>: page_view, relácie, cookies <code>_ga</code> a gclid pre Google Ads.
							E-commerce udalosti posiela signals (GA4 destinácia „Všetky okrem page_view“). Iný GA4 kód (GTM, Site Kit, ručný v hlavičke) odstráňte.
							Pri nástroji na súhlasy ho načíta <code>px.js</code> až po súhlase so štatistikou — pred súhlasom nejde do Google nič.
							Bez loadera <code>px.js</code> sa vloží len na webe bez nástroja na súhlasy.
						</p>
					</td>
				</tr>
			</table>
			<?php submit_button(); ?>
		</form>
	</div>
	<?php
}

/* -------------------------------------------------------------------------
 * Loader
 * ---------------------------------------------------------------------- */

add_action( 'wp_head', function () {
	$s = nowera_capi_settings();
	if ( empty( $s['collector_host'] ) || empty( $s['load_script'] ) ) {
		return;
	}
	$config = array();

	if ( 'none' !== $s['consent_mode'] ) {
		$config[] = 'window.nwrConsent=' . wp_json_encode( array(
			'mode'   => $s['consent_mode'],
			'prefix' => $s['consent_prefix'],
		) ) . ';';
	}
	if ( $s['ga4_tag'] ) {
		$config[] = nowera_capi_gtag_stub( $s );
	}

	// What this page is. Identical for every visitor, so it is safe in cached HTML.
	$page = nowera_capi_page_context();
	if ( $page ) {
		$config[] = 'window.nwrPage=' . wp_json_encode( $page ) . ';';
	}

	// This site's own endpoint that re-sets our identifiers from its server,
	// which Safari keeps for 90 days instead of 7. Same for every visitor.
	$config[] = 'window.nwrKeep=' . wp_json_encode( plugins_url( 'keep.php', __FILE__ ) ) . ';';

	// Where px.js picks up the browser half of an add to cart made through the
	// Store API (block buttons, custom buy boxes). Same for every visitor.
	if ( class_exists( 'WC_AJAX' ) ) {
		$config[] = 'window.nwrLegs=' . wp_json_encode( WC_AJAX::get_endpoint( 'nwr_legs' ) ) . ';';
	}

	// Hashed identifiers only for signed-in customers, whose pages are never
	// served from the shared page cache. For a guest this line could be cached
	// and handed to every later visitor as if they were the same person; guest
	// identity reaches Meta through the server leg at checkout instead.
	if ( is_user_logged_in() ) {
		$identity = array();
		$current  = nowera_capi_current_user();
		unset( $current['account'] ); // the server events carry the account
		foreach ( $current as $key => $value ) {
			$digest = nowera_capi_hash( $key, $value, $current['country'] ?? null );
			if ( $digest !== null ) {
				$identity[ $key ] = $digest;
			}
		}
		if ( $identity ) {
			$config[] = 'window.nwrUser=' . wp_json_encode( $identity ) . ';';
		}
	}

	if ( $config ) {
		printf( '<script>%s</script>' . "\n", implode( '', $config ) );
	}

	printf(
		'<script async src="https://%s/px.js"></script>' . "\n",
		esc_attr( $s['collector_host'] )
	);
}, 1 );

/**
 * The Google tag, configuration only. It keeps what only a browser tag can do:
 * page views, sessions, the _ga cookies and gclid, which the server events then
 * join. Ecommerce events come from the gateway, so none are sent from here.
 *
 * With px.js on the page, the page only names the tag (window.nwrGtag, printed
 * before px.js so it is there whenever px.js runs) under a denied consent
 * default; px.js loads it once the visitor allows statistics, so nothing goes to
 * Google before that ("basic" consent mode). Cache-safe: the same for everyone.
 */
function nowera_capi_gtag_stub( array $s ): string {
	$js = 'window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}';
	if ( 'none' !== $s['consent_mode'] ) {
		// Google wants a consent default first; a consent tool's own one wins.
		$js .= 'if(!dataLayer.some(function(a){return a&&a[0]===\'consent\'&&a[1]===\'default\';}))'
			. 'gtag(\'consent\',\'default\',{ad_storage:\'denied\',ad_user_data:\'denied\',ad_personalization:\'denied\',analytics_storage:\'denied\'});';
	}
	return $js . 'window.nwrGtag=' . wp_json_encode( $s['ga4_tag'] ) . ';';
}

/**
 * Without px.js the tag can only run straight from the page — and only on a
 * site that does not ask for consent, since nothing here could wait for it.
 */
add_action( 'wp_head', function () {
	$s = nowera_capi_settings();
	if ( ! $s['ga4_tag'] || ( ! empty( $s['load_script'] ) && ! empty( $s['collector_host'] ) ) || 'none' !== $s['consent_mode'] ) {
		return;
	}
	printf(
		'<script async src="https://www.googletagmanager.com/gtag/js?id=%1$s"></script>' . "\n" .
		'<script>window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}gtag(\'js\',new Date());gtag(\'config\',%2$s);</script>' . "\n",
		esc_attr( $s['ga4_tag'] ),
		wp_json_encode( $s['ga4_tag'] )
	);
}, 20 );

/* -------------------------------------------------------------------------
 * Consent, catalog ids, page context
 * ---------------------------------------------------------------------- */

/**
 * Whether the visitor behind this request agreed to a consent category.
 * 'marketing' gates Meta, 'statistics' gates GA4.
 */
function nowera_capi_has_consent( string $category ): bool {
	$s = nowera_capi_settings();
	if ( 'none' === $s['consent_mode'] ) {
		return true;
	}

	if ( 'faz' === $s['consent_mode'] ) {
		$map = array( 'marketing' => 'marketing', 'statistics' => 'analytics' );
		$faz = nowera_capi_faz_consent();
		return isset( $map[ $category ] ) && 'yes' === ( $faz['action'] ?? '' ) && 'yes' === ( $faz[ $map[ $category ] ] ?? '' );
	}

	if ( 'cookiescript' === $s['consent_mode'] ) {
		$map = array( 'marketing' => 'targeting', 'statistics' => 'performance' );
		return isset( $map[ $category ] ) && in_array( $map[ $category ], nowera_capi_cookiescript_categories(), true );
	}

	// Complianz reports into the WP Consent API when that plugin is present.
	if ( 'complianz' === $s['consent_mode'] && function_exists( 'wp_has_consent' ) ) {
		return (bool) wp_has_consent( $category );
	}
	$name = $s['consent_prefix'] . $category;
	return isset( $_COOKIE[ $name ] ) && 'allow' === sanitize_text_field( wp_unslash( $_COOKIE[ $name ] ) );
}

/**
 * The visitor's FAZ Cookie Manager decision as key => value, e.g.
 *   array( 'action' => 'yes', 'analytics' => 'no', 'marketing' => 'yes', 'rev' => '1' ).
 * Read only through FAZ's own helpers, which also discard a decision made under
 * an older policy revision. Without FAZ there is no valid decision at all.
 */
function nowera_capi_faz_consent(): array {
	if ( ! function_exists( 'faz_get_valid_consent_cookie' ) || ! function_exists( 'faz_parse_consent_cookie' ) ) {
		return array();
	}
	$raw = faz_get_valid_consent_cookie();
	return '' === $raw ? array() : faz_parse_consent_cookie( $raw );
}

/**
 * Categories the visitor accepted in CookieScript. Its cookie is JSON whose
 * "categories" field is itself a JSON string, e.g.
 *   {"action":"accept","categories":"[\"targeting\",\"performance\"]"}
 * WordPress adds slashes to $_COOKIE, so it has to be unslashed before decoding.
 */
function nowera_capi_cookiescript_categories(): array {
	if ( empty( $_COOKIE['CookieScriptConsent'] ) || ! is_string( $_COOKIE['CookieScriptConsent'] ) ) {
		return array();
	}
	$data = json_decode( wp_unslash( $_COOKIE['CookieScriptConsent'] ), true );
	if ( ! is_array( $data ) ) {
		return array();
	}
	$categories = $data['categories'] ?? array();
	if ( is_string( $categories ) ) {
		$categories = json_decode( $categories, true );
	}
	return is_array( $categories ) ? array_values( array_filter( $categories, 'is_string' ) ) : array();
}

/**
 * The id Meta's catalog knows this product by. Meta for WooCommerce syncs the
 * catalog, so its own helper is the source of truth; the same filter is honoured
 * when that plugin is absent so a customised retailer id still matches.
 */
function nowera_capi_content_id( \WC_Product $product ): string {
	if ( class_exists( 'WC_Facebookcommerce_Utils' ) && is_callable( array( 'WC_Facebookcommerce_Utils', 'get_fb_retailer_id' ) ) ) {
		return (string) \WC_Facebookcommerce_Utils::get_fb_retailer_id( $product );
	}
	return (string) apply_filters( 'wc_facebook_fb_retailer_id', (string) $product->get_id(), $product );
}

function nowera_capi_product_price( \WC_Product $product ): float {
	return nowera_capi_product_prices( $product )[0];
}

/**
 * The product's price as the shop shows it (what Meta gets, comparable with an
 * order total that includes VAT) and without VAT (what GA4 counts as revenue).
 */
function nowera_capi_product_prices( \WC_Product $product ): array {
	$raw  = $product->is_type( 'variable' ) ? (float) $product->get_variation_price( 'min' ) : (float) $product->get_price();
	$args = array( 'qty' => 1, 'price' => $raw );
	return array( (float) wc_get_price_including_tax( $product, $args ), (float) wc_get_price_excluding_tax( $product, $args ) );
}

/**
 * One product as GA4 and Meta describe it: catalog id, the name without the
 * variation, category path, brand and variant. Meta gets the name, brand and
 * category under its own keys (the gateway maps them).
 */
function nowera_capi_item( \WC_Product $product, $quantity = 1, ?float $price = null, ?float $price_net = null ): array {
	$parent = $product->get_parent_id() ? wc_get_product( $product->get_parent_id() ) : null;
	$base   = $parent ?: $product;
	if ( null === $price ) {
		list( $price, $price_net ) = nowera_capi_product_prices( $product );
	}
	$decimals = wc_get_price_decimals();
	$item     = array(
		'id'         => nowera_capi_content_id( $product ),
		'item_name'  => wp_strip_all_tags( $base->get_name() ),
		'quantity'   => (int) $quantity,
		'item_price' => round( $price, $decimals ),
		// GA4 counts revenue without VAT; Meta never sees this field.
		'price_net'  => round( null === $price_net ? $price : $price_net, $decimals ),
	);
	foreach ( nowera_capi_category_path( $base->get_id() ) as $i => $name ) {
		$item[ 0 === $i ? 'item_category' : 'item_category' . ( $i + 1 ) ] = $name;
	}
	$brand = nowera_capi_brand( $base );
	if ( '' !== $brand ) {
		$item['item_brand'] = $brand;
	}
	if ( $product->is_type( 'variation' ) ) {
		$variant = wp_strip_all_tags( (string) wc_get_formatted_variation( $product, true, false, false ) );
		if ( '' !== $variant ) {
			$item['item_variant'] = $variant;
		}
	}
	return $item;
}

/** Category names from the top down to the product's deepest category, at most five. */
function nowera_capi_category_path( int $product_id ): array {
	static $cache = array();
	if ( isset( $cache[ $product_id ] ) ) {
		return $cache[ $product_id ];
	}
	$path  = array();
	$terms = get_the_terms( $product_id, 'product_cat' );
	if ( is_array( $terms ) && $terms ) {
		$best  = null;
		$depth = -1;
		foreach ( $terms as $term ) {
			$d = count( get_ancestors( $term->term_id, 'product_cat', 'taxonomy' ) );
			if ( $d > $depth ) {
				$best  = $term;
				$depth = $d;
			}
		}
		if ( $best && (int) $best->term_id !== (int) get_option( 'default_product_cat' ) ) {
			foreach ( array_reverse( get_ancestors( $best->term_id, 'product_cat', 'taxonomy' ) ) as $ancestor ) {
				$term = get_term( $ancestor, 'product_cat' );
				if ( $term && ! is_wp_error( $term ) ) {
					$path[] = wp_strip_all_tags( $term->name );
				}
			}
			$path[] = wp_strip_all_tags( $best->name );
		}
	}
	$path = (array) apply_filters( 'nowera_capi_item_categories', array_slice( $path, 0, 5 ), $product_id );
	return $cache[ $product_id ] = array_values( array_slice( $path, 0, 5 ) );
}

/** The product's brand from the common brand taxonomies or a brand attribute; filterable. */
function nowera_capi_brand( \WC_Product $product ): string {
	$brand = '';
	foreach ( array( 'product_brand', 'pwb-brand', 'yith_product_brand', 'berocket_brand', 'pa_brand', 'pa_znacka' ) as $taxonomy ) {
		if ( ! taxonomy_exists( $taxonomy ) ) {
			continue;
		}
		$terms = get_the_terms( $product->get_id(), $taxonomy );
		if ( is_array( $terms ) && $terms ) {
			$brand = $terms[0]->name;
			break;
		}
	}
	return (string) apply_filters( 'nowera_capi_item_brand', wp_strip_all_tags( $brand ), $product );
}

/** An order (or refund) line as an item; `$priced_by` is the refund for a refund line. */
function nowera_capi_order_item( \WC_Order_Item_Product $line, \WC_Abstract_Order $priced_by ): array {
	$product  = $line->get_product();
	$quantity = abs( (int) $line->get_quantity() );
	$price    = abs( (float) $priced_by->get_item_total( $line, true, true ) );
	$net      = abs( (float) $priced_by->get_item_total( $line, false, true ) );
	$item     = $product
		? nowera_capi_item( $product, $quantity, $price, $net )
		: array(
			'id'         => (string) ( $line->get_variation_id() ?: $line->get_product_id() ),
			'item_name'  => $line->get_name(),
			'quantity'   => $quantity,
			'item_price' => $price,
			'price_net'  => $net,
		);
	// A coupon's share per unit, without VAT like GA4's price, next to the discounted price.
	if ( $quantity && ! $priced_by instanceof \WC_Order_Refund ) {
		$discount = ( (float) $line->get_subtotal() - (float) $line->get_total() ) / $quantity;
		if ( $discount > 0.004 ) {
			$item['discount'] = round( $discount, wc_get_price_decimals() );
		}
	}
	return $item;
}

/** What is in the cart, as items. */
function nowera_capi_cart_items(): array {
	$items = array();
	if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
		return $items;
	}
	foreach ( WC()->cart->get_cart() as $line ) {
		if ( empty( $line['data'] ) || ! $line['data'] instanceof \WC_Product ) {
			continue;
		}
		$quantity = max( 1, (int) $line['quantity'] );
		$items[]  = nowera_capi_item( $line['data'], $quantity, ( (float) $line['line_total'] + (float) $line['line_tax'] ) / $quantity, (float) $line['line_total'] / $quantity );
	}
	return $items;
}

/**
 * A single published post of a type chosen under "Katalóg z vlastného typu
 * obsahu", described like a product page, so px.js fires ViewContent (GA4
 * view_item) from it: content_ids is the post ID, which is what the site's own
 * catalog feed uses as the item id, content_type the one chosen for the type.
 *
 * Sites add a price or category with the nowera_capi_cpt_item filter, which gets
 * the item (id, item_name, quantity) and the WP_Post and may set item_price,
 * price_net, currency (ISO 4217; WooCommerce's, when that is installed and none
 * is given), item_brand, item_variant and item_category…item_category5, or return
 * false to leave the post out. The id stays the post ID. Value and currency go
 * out only when there is both a price and a currency. Whatever the filter adds
 * ends up in cached HTML, so it must be the same for every visitor.
 */
function nowera_capi_cpt_context(): ?array {
	$catalog = nowera_capi_settings()['cpt_catalog'];
	if ( ! is_array( $catalog ) || ! $catalog || ! is_singular( array_keys( $catalog ) ) ) {
		return null;
	}
	$post         = get_queried_object();
	$content_type = $post instanceof \WP_Post ? ( $catalog[ $post->post_type ] ?? '' ) : '';
	if ( ! $post instanceof \WP_Post || 'product' === $post->post_type || ! isset( NOWERA_CAPI_CPT_CONTENT_TYPES[ $content_type ] )
		|| 'publish' !== $post->post_status || '' !== (string) $post->post_password ) {
		return null;
	}
	$id     = (string) $post->ID;
	// As written, not as stored: WordPress keeps "&" in a title as "&amp;". Tags go
	// after decoding, so an encoded one cannot come back as markup.
	$name   = trim( wp_strip_all_tags( html_entity_decode( (string) $post->post_title, ENT_QUOTES, 'UTF-8' ) ) );
	$filter = apply_filters( 'nowera_capi_cpt_item', array( 'id' => $id, 'item_name' => $name, 'quantity' => 1 ), $post );
	if ( ! is_array( $filter ) ) {
		return null; // the site left this one out
	}
	$text = function ( $value, int $max ) {
		return is_scalar( $value ) ? mb_substr( trim( wp_strip_all_tags( html_entity_decode( (string) $value, ENT_QUOTES, 'UTF-8' ) ) ), 0, $max ) : '';
	};
	$item = array(
		'id'        => $id,
		'item_name' => $text( $filter['item_name'] ?? '', 200 ) ?: $name,
		'quantity'  => 1,
	);
	// A price JSON can carry: "1e309" is numeric too, and would break the page's script.
	$amount = function ( $value ): ?float {
		return is_numeric( $value ) && is_finite( (float) $value ) && (float) $value >= 0 ? (float) $value : null;
	};
	$price    = $amount( $filter['item_price'] ?? null );
	$currency = strtoupper( $text( $filter['currency'] ?? '', 3 ) );
	if ( ! preg_match( '/^[A-Z]{3}$/', $currency ) ) {
		$currency = function_exists( 'get_woocommerce_currency' ) ? (string) get_woocommerce_currency() : '';
	}
	if ( null !== $price && preg_match( '/^[A-Z]{3}$/', $currency ) ) {
		$item['item_price'] = round( $price, 2 );
		// GA4 counts revenue without VAT; Meta never sees this field.
		$net               = $amount( $filter['price_net'] ?? null );
		$item['price_net'] = null === $net ? $item['item_price'] : round( $net, 2 );
	} else {
		$price = null;
	}
	foreach ( array( 'item_brand', 'item_variant', 'item_category', 'item_category2', 'item_category3', 'item_category4', 'item_category5' ) as $key ) {
		$value = $text( $filter[ $key ] ?? '', 100 );
		if ( '' !== $value ) {
			$item[ $key ] = $value;
		}
	}
	$data = array(
		'content_name' => $item['item_name'],
		'content_ids'  => array( $id ),
		'content_type' => $content_type,
		'contents'     => array( $item ),
	);
	if ( isset( $item['item_category'] ) ) {
		$data['content_category'] = $item['item_category'];
	}
	if ( null !== $price ) {
		$data['value']     = $item['item_price'];
		$data['value_net'] = $item['price_net'];
		$data['currency']  = $currency;
	}
	return array( 'type' => 'product', 'data' => $data );
}

/**
 * Describes the current shop page for the browser leg: a product, a category
 * or a search. Mirrors what Meta for WooCommerce used to send, so catalog
 * matching and audiences keep working after its own tracking is switched off.
 */
function nowera_capi_page_context(): ?array {
	// A listing, a vehicle or another item of the site's own catalog; also on
	// sites without WooCommerce.
	$item = nowera_capi_cpt_context();
	if ( $item ) {
		return $item;
	}
	if ( ! function_exists( 'is_product' ) ) {
		return null;
	}
	$currency = get_woocommerce_currency();

	if ( is_product() ) {
		$product = wc_get_product( get_queried_object_id() );
		if ( ! $product ) {
			return null;
		}
		$id    = nowera_capi_content_id( $product );
		$item  = nowera_capi_item( $product );
		$price = $item['item_price'];
		$cats  = wp_get_post_terms( $product->get_id(), 'product_cat', array( 'fields' => 'names' ) );
		return array(
			'type' => 'product',
			'data' => array(
				'content_name'     => wp_strip_all_tags( $product->get_name() ),
				'content_ids'      => array( $id ),
				'content_type'     => $product->is_type( array( 'variable', 'grouped' ) ) ? 'product_group' : 'product',
				'contents'         => array( $item ),
				'content_category' => is_array( $cats ) ? implode( ', ', $cats ) : '',
				'value'            => $price,
				'value_net'        => $item['price_net'],
				'currency'         => $currency,
			),
		);
	}

	// The cart page is never served from the page cache (WooCommerce excludes it),
	// so it may describe this visitor's own cart.
	if ( function_exists( 'is_cart' ) && is_cart() && WC()->cart && ! WC()->cart->is_empty() ) {
		$items = nowera_capi_cart_items();
		return array(
			'type' => 'cart',
			'data' => array(
				'value'        => (float) WC()->cart->get_total( 'edit' ),
				'value_net'    => round( (float) WC()->cart->get_subtotal() - (float) WC()->cart->get_discount_total(), wc_get_price_decimals() ),
				'currency'     => $currency,
				'content_ids'  => array_values( array_unique( array_column( $items, 'id' ) ) ),
				'contents'     => $items,
				'content_type' => 'product',
				'num_items'    => WC()->cart->get_cart_contents_count(),
			),
		);
	}

	global $wp_query;
	// The first ten products describe the list for ViewCategory/Search; every
	// product on the page (with its address) lets px.js report which one was
	// clicked (SelectItem).
	$listed = function ( string $list ) use ( $wp_query ) {
		$ids      = array();
		$contents = array();
		$links    = array();
		$group    = false;
		foreach ( array_slice( (array) $wp_query->posts, 0, 60 ) as $index => $post ) {
			$product = wc_get_product( $post );
			if ( ! $product ) {
				continue;
			}
			$item                   = nowera_capi_item( $product );
			$item['index']          = $index;
			$item['item_list_name'] = $list;
			$links[]                = array_merge( $item, array( 'url' => get_permalink( $product->get_id() ) ) );
			if ( $index < 10 ) {
				$ids[]      = $item['id'];
				$contents[] = $item;
			}
			$group = $group || $product->is_type( 'variable' );
		}
		return array( $ids, $contents, $group ? 'product_group' : 'product', $links );
	};

	if ( is_product_category() ) {
		$term = get_queried_object();
		list( $ids, $contents, $type, $links ) = $listed( wp_strip_all_tags( $term->name ) );
		return array(
			'type'  => 'category',
			'links' => $links,
			'data' => array(
				'content_name'     => $term->name,
				'content_category' => $term->name,
				'item_list_name'   => wp_strip_all_tags( $term->name ),
				'content_ids'      => $ids,
				'content_type'     => $type,
				'contents'         => $contents,
				'currency'         => $currency,
			),
		);
	}

	if ( is_search() && '' !== get_search_query() && 'product' === get_query_var( 'post_type' ) ) {
		list( $ids, $contents, $type, $links ) = $listed( 'search' );
		return array(
			'type'  => 'search',
			'links' => $links,
			'data' => array(
				'search_string' => get_search_query(),
				'item_list_name' => 'search',
				'content_ids'   => $ids,
				'content_type'  => $type,
				'contents'      => $contents,
				'currency'      => $currency,
			),
		);
	}

	return null;
}

/* -------------------------------------------------------------------------
 * Transport
 * ---------------------------------------------------------------------- */

/**
 * E-mail and phone hashed the way Google matches them, which is not Meta's way:
 * Gmail addresses without dots in the name, the phone in E.164 with its "+".
 * Values that arrive hashed already (a returning visitor's cookie) are Meta's
 * hashes and cannot be converted, so they are left out.
 */
function nowera_capi_google_user( array $user ): array {
	$out   = array();
	$email = strtolower( trim( (string) ( $user['em'] ?? '' ) ) );
	if ( '' !== $email && ! preg_match( '/^[a-f0-9]{64}$/', $email ) && is_email( $email ) ) {
		list( $name, $domain ) = explode( '@', $email, 2 );
		if ( in_array( $domain, array( 'gmail.com', 'googlemail.com' ), true ) ) {
			$name = str_replace( '.', '', $name );
		}
		$out['sha256_email_address'] = array( hash( 'sha256', $name . '@' . $domain ) );
	}
	$phone = (string) ( $user['ph'] ?? '' );
	if ( '' !== $phone && ! preg_match( '/^[a-f0-9]{64}$/i', $phone ) ) {
		$digits = nowera_capi_phone_digits( $phone, $user['country'] ?? null );
		if ( strlen( $digits ) >= 8 ) {
			$out['sha256_phone_number'] = array( hash( 'sha256', '+' . $digits ) );
		}
	}
	return $out;
}

/**
 * Meta's normalization rules, mirrored from the gateway's hash.js so a value
 * hashed here produces the same digest as one hashed there.
 */
function nowera_capi_hash( string $key, $value, ?string $country = null ): ?string {
	if ( $value === null || $value === '' ) {
		return null;
	}
	$value = (string) $value;
	if ( preg_match( '/^[a-f0-9]{64}$/i', $value ) ) {
		return strtolower( $value ); // already hashed upstream
	}

	$lower = mb_strtolower( trim( $value ), 'UTF-8' );
	switch ( $key ) {
		case 'em':
			$normalized = $lower;
			break;
		case 'ph':
			$normalized = nowera_capi_phone_digits( $value, $country );
			break;
		case 'fn':
		case 'ln':
		case 'ct':
			$normalized = preg_replace( '/[^\p{L}]/u', '', $lower );
			break;
		case 'st':
			$normalized = substr( preg_replace( '/[^\p{L}]/u', '', $lower ), 0, 2 );
			break;
		case 'zp':
			$normalized = preg_replace( '/\s/', '', $lower );
			break;
		case 'country':
			$normalized = substr( $lower, 0, 2 );
			break;
		default:
			$normalized = $lower;
	}

	return $normalized === '' ? null : hash( 'sha256', $normalized );
}

/**
 * A phone number as Meta keys it: digits only, country code first, no plus and
 * no trunk prefix. $country is the ISO code the number belongs to (the billing
 * country); without one the shop's own country is assumed.
 */
function nowera_capi_phone_digits( string $value, ?string $country ): string {
	$digits = preg_replace( '/\D/', '', $value );
	if ( '' === $digits ) {
		return '';
	}

	// Written internationally: +421…, 00421…, or the common +421 0905… slip.
	if ( str_starts_with( ltrim( $value ), '+' ) || str_starts_with( $digits, '00' ) ) {
		$digits = ltrim( $digits, '0' );
		$codes  = NOWERA_CAPI_CALLING_CODES;
		uasort( $codes, fn( $a, $b ) => strlen( $b ) <=> strlen( $a ) );
		foreach ( $codes as $iso => $code ) {
			if ( str_starts_with( $digits, $code ) ) {
				$trunk = NOWERA_CAPI_TRUNK_PREFIXES[ $iso ] ?? '0';
				$rest  = substr( $digits, strlen( $code ) );
				if ( '' !== $trunk && str_starts_with( $rest, $trunk ) ) {
					$digits = $code . substr( $rest, strlen( $trunk ) );
				}
				break;
			}
		}
		return $digits;
	}

	$country = strtoupper( (string) $country );
	if ( ! preg_match( '/^[A-Z]{2}$/', $country ) ) {
		$country = function_exists( 'WC' ) && WC()->countries ? (string) WC()->countries->get_base_country() : '';
	}
	$code = NOWERA_CAPI_CALLING_CODES[ $country ] ?? null;
	if ( null === $code ) {
		return ltrim( $digits, '0' ); // a country we have no rule for
	}

	// Typed with the country code but without the plus: 421905123456.
	if ( str_starts_with( $digits, $code ) && strlen( $digits ) >= strlen( $code ) + 8 ) {
		return $digits;
	}
	$trunk = NOWERA_CAPI_TRUNK_PREFIXES[ $country ] ?? '0';
	if ( '' !== $trunk && str_starts_with( $digits, $trunk ) ) {
		$digits = substr( $digits, strlen( $trunk ) );
	}
	return $code . $digits;
}

/**
 * GA4 joins a Measurement Protocol hit to the visitor's browser session by these
 * two ids. Without them the event lands as Direct and is useless for Ads import.
 */
/**
 * The session id inside a _ga_<stream> cookie, in either format GA4 writes:
 * GS2.1.s<session>$o<count>$g… (current) or GS1.1.<session>.<count>.… (older).
 */
function nowera_capi_ga_session( string $raw ): ?string {
	if ( preg_match( '/^GS2\.\d+\.(.*)$/', $raw, $m ) ) {
		return preg_match( '/(?:^|\$)s(\d+)/', $m[1], $s ) ? $s[1] : null;
	}
	$parts = explode( '.', $raw );
	return count( $parts ) >= 3 && ctype_digit( $parts[2] ) ? $parts[2] : null;
}

function nowera_capi_ga_ids(): array {
	$client_id = null;
	$session_id = null;

	if ( ! empty( $_COOKIE['_ga'] ) ) {
		$parts = explode( '.', sanitize_text_field( wp_unslash( $_COOKIE['_ga'] ) ) );
		if ( count( $parts ) >= 4 ) {
			$client_id = $parts[ count( $parts ) - 2 ] . '.' . $parts[ count( $parts ) - 1 ];
		}
	}

	// The session cookie is named after the stream id, which we do not configure
	// anywhere — find whichever _ga_* cookie this property set.
	foreach ( $_COOKIE as $name => $value ) {
		if ( strpos( $name, '_ga_' ) !== 0 ) {
			continue;
		}
		$session_id = nowera_capi_ga_session( sanitize_text_field( wp_unslash( $value ) ) );
		if ( null !== $session_id ) {
			break;
		}
	}

	return array( 'client_id' => $client_id, 'session_id' => $session_id );
}

/* -------------------------------------------------------------------------
 * Returning customers
 * ---------------------------------------------------------------------- */

/**
 * Hashed contact details stored after a purchase or a login. Read by px.js on
 * every later page (cached ones too) and by the server events below, so a
 * returning customer is recognised before they type anything.
 */
function nowera_capi_stored_user(): array {
	if ( empty( $_COOKIE['_nwr_ud'] ) || ! is_string( $_COOKIE['_nwr_ud'] ) ) {
		return array();
	}
	$data = json_decode( wp_unslash( $_COOKIE['_nwr_ud'] ), true );
	if ( ! is_array( $data ) ) {
		return array();
	}
	$out = array();
	foreach ( NOWERA_CAPI_STORED_KEYS as $key ) {
		if ( isset( $data[ $key ] ) && is_string( $data[ $key ] ) && preg_match( '/^[a-f0-9]{64}$/i', $data[ $key ] ) ) {
			$out[ $key ] = strtolower( $data[ $key ] );
		}
	}
	return $out;
}

/**
 * Store the hashed identity for later visits. Only with marketing consent, and
 * only when there is an email or a phone: a name alone identifies nobody.
 */
function nowera_capi_remember_user( array $raw ): void {
	$s = nowera_capi_settings();
	if ( empty( $s['collector_host'] ) || headers_sent() || ! nowera_capi_has_consent( 'marketing' ) ) {
		return;
	}
	$hashed = array();
	foreach ( NOWERA_CAPI_STORED_KEYS as $key ) {
		$digest = isset( $raw[ $key ] ) ? nowera_capi_hash( $key, $raw[ $key ], $raw['country'] ?? null ) : null;
		if ( $digest !== null ) {
			$hashed[ $key ] = $digest;
		}
	}
	if ( empty( $hashed['em'] ) && empty( $hashed['ph'] ) ) {
		return;
	}

	// A response that sets a personal cookie must never be served from a page cache.
	if ( ! defined( 'DONOTCACHEPAGE' ) ) {
		define( 'DONOTCACHEPAGE', true );
	}
	do_action( 'litespeed_control_set_nocache', 'nowera-capi: returning-customer cookie' );
	nocache_headers();

	$value = wp_json_encode( $hashed );
	setcookie( '_nwr_ud', $value, array(
		'expires'  => time() + 90 * DAY_IN_SECONDS,
		'path'     => '/',
		'secure'   => is_ssl(),
		'httponly' => false, // px.js reads it
		'samesite' => 'Lax',
	) );
	$_COOKIE['_nwr_ud'] = wp_slash( $value );
}

/**
 * A visitor arriving from a Meta ad carries ?fbclid=. The loader normally turns
 * it into the _fbc cookie; this is the fallback for when it cannot run — the
 * click id is what ties the later purchase back to the ad.
 */
function nowera_capi_capture_fbclid(): void {
	if ( empty( $_GET['fbclid'] ) || headers_sent() ) {
		return;
	}
	if ( ! nowera_capi_has_consent( 'marketing' ) ) {
		return;
	}
	$fbclid = sanitize_text_field( wp_unslash( $_GET['fbclid'] ) );
	if ( ! preg_match( '/^[A-Za-z0-9._-]{1,500}$/', $fbclid ) ) {
		return;
	}
	// A new ad click replaces the stored click id; the same click keeps it.
	$stored = isset( $_COOKIE['_fbc'] ) && is_string( $_COOKIE['_fbc'] ) ? wp_unslash( $_COOKIE['_fbc'] ) : '';
	if ( preg_match( '/^fb\.\d\.(\d{10,13})\.([A-Za-z0-9._-]{1,700})$/', $stored, $m ) ) {
		$same = $m[2] === $fbclid || 0 === strpos( $m[2], $fbclid . '.' );
		// The same click keeps its time, expired or not: reopening an old ad link
		// is not a new click (the gateway leaves an expired one out).
		if ( $same ) {
			return;
		}
	}

	// Meta's own shape: fb.<subdomain index>.<created at, ms>.<click id>.
	$value  = 'fb.1.' . ( time() * 1000 ) . '.' . $fbclid;
	$host   = (string) wp_parse_url( home_url(), PHP_URL_HOST );
	$domain = ( defined( 'COOKIE_DOMAIN' ) && COOKIE_DOMAIN ) ? COOKIE_DOMAIN : '.' . preg_replace( '/^www\./', '', $host );

	// This response now carries one visitor's click id, so it must not be cached.
	if ( ! defined( 'DONOTCACHEPAGE' ) ) {
		define( 'DONOTCACHEPAGE', true );
	}
	do_action( 'litespeed_control_set_nocache', 'nowera-capi: click id cookie' );
	nocache_headers();

	setcookie( '_fbc', $value, array(
		'expires'  => time() + 90 * DAY_IN_SECONDS,
		'path'     => '/',
		'domain'   => $domain,
		'secure'   => is_ssl(),
		'httponly' => false, // the Meta pixel reads it too
		'samesite' => 'Lax',
	) );
	$_COOKIE['_fbc'] = $value;
}

// The thank-you page of a fresh order: the buyer's own contact details. The order
// key proves the link came from checkout, the age check keeps an old forwarded
// link from tagging somebody else's browser.
add_action( 'template_redirect', function () {
	nowera_capi_capture_fbclid();

	if ( ! function_exists( 'is_order_received_page' ) || ! is_order_received_page() ) {
		return;
	}
	$order_id = absint( get_query_var( 'order-received' ) );
	$key      = isset( $_GET['key'] ) ? wc_clean( wp_unslash( $_GET['key'] ) ) : '';
	$order    = $order_id ? wc_get_order( $order_id ) : false;
	if ( ! $order || '' === $key || ! hash_equals( $order->get_order_key(), (string) $key ) ) {
		return;
	}
	$created = $order->get_date_created();
	if ( ! $created || $created->getTimestamp() < time() - DAY_IN_SECONDS ) {
		return;
	}
	nowera_capi_remember_user( nowera_capi_user_from_order( $order ) );
}, 5 );

// A login: the account's billing details, which are usually the ones ads know.
add_action( 'wp_login', function ( $login, $user ) {
	if ( ! $user instanceof \WP_User ) {
		return;
	}
	$raw = array(
		'em' => $user->user_email,
		'fn' => $user->first_name,
		'ln' => $user->last_name,
	);
	if ( class_exists( 'WC_Customer' ) ) {
		try {
			$customer = new \WC_Customer( $user->ID );
			$raw      = array_merge( $raw, array_filter( array(
				'em'      => $customer->get_billing_email(),
				'ph'      => $customer->get_billing_phone(),
				'fn'      => $customer->get_billing_first_name(),
				'ln'      => $customer->get_billing_last_name(),
				'ct'      => $customer->get_billing_city(),
				'zp'      => $customer->get_billing_postcode(),
				'country' => $customer->get_billing_country(),
			) ) );
		} catch ( \Exception $e ) {
			// No customer record: the account fields above are still useful.
		}
	}
	nowera_capi_remember_user( $raw );
}, 10, 2 );

/** First-party visitor id set by the gateway; often a guest's only stable identifier. */
function nowera_capi_visitor_id(): ?string {
	return empty( $_COOKIE['_nwr_id'] )
		? null
		: sanitize_text_field( wp_unslash( $_COOKIE['_nwr_id'] ) );
}

/** Whether an address lies in a CIDR range, IPv4 or IPv6. */
function nowera_capi_ip_in( string $ip, string $cidr ): bool {
	[ $net, $bits ] = array_pad( explode( '/', $cidr, 2 ), 2, null );
	$a = @inet_pton( $ip );
	$b = @inet_pton( (string) $net );
	if ( false === $a || false === $b || strlen( $a ) !== strlen( $b ) ) {
		return false;
	}
	$bits  = (int) $bits;
	$bytes = intdiv( $bits, 8 );
	if ( substr( $a, 0, $bytes ) !== substr( $b, 0, $bytes ) ) {
		return false;
	}
	$rest = $bits % 8;
	if ( 0 === $rest ) {
		return true;
	}
	$mask = ( 0xff << ( 8 - $rest ) ) & 0xff;
	return ( ord( $a[ $bytes ] ) & $mask ) === ( ord( $b[ $bytes ] ) & $mask );
}

/**
 * The visitor's address. CF-Connecting-IP and X-Forwarded-For are believed only
 * when the request came through Cloudflare or a proxy on the hosting's own
 * network; from anywhere else they are whatever the sender typed.
 */
function nowera_capi_client_ip(): string {
	$remote = isset( $_SERVER['REMOTE_ADDR'] ) ? trim( sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) ) : '';
	$remote = filter_var( $remote, FILTER_VALIDATE_IP ) ? $remote : '';
	$proxied = '' === $remote
		|| ! filter_var( $remote, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE );
	foreach ( NOWERA_CAPI_CLOUDFLARE as $range ) {
		if ( $proxied ) {
			break;
		}
		$proxied = nowera_capi_ip_in( $remote, $range );
	}
	if ( $proxied ) {
		foreach ( array( 'HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR' ) as $key ) {
			if ( ! empty( $_SERVER[ $key ] ) ) {
				$ip = trim( explode( ',', sanitize_text_field( wp_unslash( $_SERVER[ $key ] ) ) )[0] );
				if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) {
					return $ip;
				}
			}
		}
	}
	return $remote;
}

/**
 * The referrer of the page this request renders, for events fired during a
 * full page load (checkout, thank-you page). An AJAX or REST call's referrer is
 * the page itself, not the one before it, so those get none. Query string and
 * fragment are dropped: on a same-site referrer they can hold order keys.
 */
function nowera_capi_page_referrer( ?string $event_url ): ?string {
	if ( empty( $_SERVER['HTTP_REFERER'] ) || wp_doing_ajax() || wp_doing_cron() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
		return null;
	}
	$parts = wp_parse_url( esc_url_raw( wp_unslash( $_SERVER['HTTP_REFERER'] ) ) );
	if ( empty( $parts['scheme'] ) || empty( $parts['host'] ) || ! in_array( $parts['scheme'], array( 'http', 'https' ), true ) ) {
		return null;
	}
	$referrer = $parts['scheme'] . '://' . $parts['host'] . ( isset( $parts['port'] ) ? ':' . $parts['port'] : '' ) . ( $parts['path'] ?? '/' );
	if ( $event_url && strtok( $event_url, '?#' ) === $referrer ) {
		return null; // the page referring to itself, e.g. a form posted back
	}
	return $referrer;
}

/**
 * Whether the buyer has ordered before: an earlier order under the same account
 * or billing email that was not abandoned, failed or cancelled. Custom statuses
 * (shipped, delivered…) count, since they come after payment.
 */
function nowera_capi_customer_segment( \WC_Order $order ): ?string {
	$email       = (string) $order->get_billing_email();
	$customer_id = (int) $order->get_customer_id();
	if ( '' === $email && ! $customer_id ) {
		return null;
	}

	$skip     = array( 'wc-pending', 'wc-failed', 'wc-cancelled', 'wc-checkout-draft' );
	$statuses = array_values( array_diff( array_keys( wc_get_order_statuses() ), $skip ) );
	$args     = array(
		'type'    => 'shop_order',
		'status'  => $statuses,
		'exclude' => array( $order->get_id() ),
		'limit'   => 1,
		'return'  => 'ids',
	);
	$created = $order->get_date_created();
	if ( $created ) {
		$args['date_created'] = '<' . $created->getTimestamp();
	}

	$lookups = array();
	if ( $customer_id ) {
		$lookups[] = array( 'customer_id' => $customer_id );
	}
	if ( '' !== $email ) {
		$lookups[] = array( 'billing_email' => $email );
		if ( strtolower( $email ) !== $email ) {
			$lookups[] = array( 'billing_email' => strtolower( $email ) );
		}
	}
	foreach ( $lookups as $lookup ) {
		if ( wc_get_orders( array_merge( $args, $lookup ) ) ) {
			return 'existing_customer_to_business';
		}
	}
	return 'new_customer_to_business';
}

/**
 * What the current request tells us about the visitor: consent, and the
 * identifiers that may travel with it. An event built later, when the visitor
 * is gone (a payment confirmed by the gateway), passes a stored copy instead.
 */
function nowera_capi_request_context(): array {
	$marketing  = nowera_capi_has_consent( 'marketing' );
	$statistics = nowera_capi_has_consent( 'statistics' );
	$ga         = nowera_capi_ga_ids();
	$cookie     = function ( string $name ) use ( $marketing ) {
		return ( $marketing && isset( $_COOKIE[ $name ] ) ) ? sanitize_text_field( wp_unslash( $_COOKIE[ $name ] ) ) : null;
	};
	return array(
		'marketing'     => $marketing,
		'statistics'    => $statistics,
		'fbp'           => $cookie( '_fbp' ),
		'fbc'           => $cookie( '_fbc' ),
		// No cookie yet on the very landing page the ad click opened.
		'fbclid'        => ( $marketing && ! empty( $_GET['fbclid'] ) ) ? sanitize_text_field( wp_unslash( $_GET['fbclid'] ) ) : null,
		'ga_client_id'  => $ga['client_id'],
		'ga_session_id' => $ga['session_id'],
		'ip'            => nowera_capi_client_ip(),
		'ua'            => isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '',
	);
}

/**
 * Queue one event for the gateway; it leaves after the page has been sent to
 * the visitor (see nowera_capi_flush_outbox). Returns what happened, so a caller
 * can record it on the order: 'marketing' (Meta will get it), 'statistics' (only
 * GA4 may), 'none' (the visitor gave no consent) or 'not_configured'. A Purchase
 * passes its order, so a failed delivery is retried from the order.
 */
function nowera_capi_send( string $event_name, string $event_id, array $user, array $props, ?string $url = null, ?array $ctx = null, ?int $order_id = null ): string {
	$s = nowera_capi_settings();
	if ( empty( $s['collector_host'] ) || empty( $s['ingest_secret'] ) ) {
		return 'not_configured';
	}

	$ctx        = $ctx ?? nowera_capi_request_context();
	$marketing  = ! empty( $ctx['marketing'] );
	$statistics = ! empty( $ctx['statistics'] );
	if ( ! $marketing && ! $statistics ) {
		return 'none'; // nobody may receive this event
	}
	// A customer account: GA4's user_id, the same person on every device. Hashed
	// with the site's address, so it is no WordPress user number in the clear.
	$account = ! empty( $user['account'] ) ? hash( 'sha256', 'nwr-account|' . home_url( '/' ) . '|' . $user['account'] ) : null;
	unset( $user['account'] );
	// Contact data under Google's normalisation, for GA4 user-provided data and
	// Google Ads enhanced conversions. Advertising use: marketing consent only.
	$google_user = $marketing ? nowera_capi_google_user( $user ) : array();
	if ( ! $marketing ) {
		// Contact details and the visitor id are only for advertising use.
		$user = array_intersect_key( $user, array( 'country' => true ) );
	}

	$hashed = array();
	foreach ( $user as $key => $value ) {
		$digest = nowera_capi_hash( $key, $value, $user['country'] ?? null );
		if ( $digest !== null ) {
			$hashed[ $key ] = $digest;
		}
	}

	$source_url = $url ?: home_url( add_query_arg( array() ) );

	$payload = array(
		'event_name'        => $event_name,
		'event_id'          => $event_id,
		'event_time'        => isset( $ctx['event_time'] ) ? (int) $ctx['event_time'] : time(),
		'ga_client_id'      => $ctx['ga_client_id'] ?? null,
		'ga_session_id'     => $ctx['ga_session_id'] ?? null,
		'event_source_url'  => $source_url,
		'referrer_url'      => array_key_exists( 'referrer_url', $ctx ) ? $ctx['referrer_url'] : nowera_capi_page_referrer( $source_url ),
		'action_source'     => 'website',
		'user_data'         => $hashed,
		'account_id'        => $account,
		'google_user'       => $google_user ?: null,
		'custom_data'       => $props,
		'fbp'               => $marketing ? ( $ctx['fbp'] ?? null ) : null,
		'fbc'               => $marketing ? ( $ctx['fbc'] ?? null ) : null,
		'fbclid'            => $marketing ? ( $ctx['fbclid'] ?? null ) : null,
		'client_ip_address' => $ctx['ip'] ?? '',
		'client_user_agent' => $ctx['ua'] ?? '',
	);
	if ( 'none' !== $s['consent_mode'] ) {
		$payload['consent'] = array( 'marketing' => $marketing, 'statistics' => $statistics );
	}
	// No page ever showed this event (a refund, a purchase paid without a return
	// to the site): an analytics tag in the browser cannot have reported it.
	if ( ! empty( $ctx['browserless'] ) ) {
		$payload['browserless'] = true;
	}
	nowera_capi_outbox( array(
		'event'    => $event_name,
		'body'     => wp_json_encode( $payload ),
		'order_id' => $order_id,
	) );

	return $marketing ? 'marketing' : 'statistics';
}

/* -------------------------------------------------------------------------
 * Delivery, after the page has gone to the visitor
 * ---------------------------------------------------------------------- */

/**
 * Events of this request wait here. Called with an event, adds it (and makes
 * sure the queue is flushed at shutdown); called without, hands the queue over
 * and empties it.
 */
function nowera_capi_outbox( ?array $item = null ): array {
	static $queue  = array();
	static $hooked = false;
	if ( null === $item ) {
		$out   = $queue;
		$queue = array();
		return $out;
	}
	$queue[] = $item;
	if ( ! $hooked ) {
		// Late: after WordPress has flushed the page and WooCommerce saved its session.
		add_action( 'shutdown', 'nowera_capi_flush_outbox', 1000 );
		$hooked = true;
	}
	return $queue;
}

/**
 * Send what this request queued. First the response is finished for the
 * browser (LiteSpeed and PHP-FPM can do that), so the visitor never waits for
 * the gateway; then each event goes with a short timeout. While the gateway is
 * down, nothing is tried for a minute, so an outage cannot tie up the site's PHP
 * workers. A Purchase that did not arrive is retried from its order.
 */
function nowera_capi_flush_outbox( bool $finish = true ): void {
	$queue = nowera_capi_outbox();
	if ( ! $queue ) {
		return;
	}
	if ( $finish ) {
		if ( function_exists( 'litespeed_finish_request' ) ) {
			litespeed_finish_request();
		} elseif ( function_exists( 'fastcgi_finish_request' ) ) {
			fastcgi_finish_request();
		}
	}
	foreach ( $queue as $item ) {
		$error = nowera_capi_deliver( $item['body'] );
		if ( null === $error ) {
			continue;
		}
		if ( ! empty( $item['order_id'] ) ) {
			nowera_capi_purchase_failed( (int) $item['order_id'], $error );
		} elseif ( nowera_capi_gateway_paused() ) {
			// An outage, not this site's mistake: keep the event and try again.
			nowera_capi_retry_later( $item['body'], 1 );
		}
	}
}

/**
 * An event that met a gateway outage waits and goes again with its original
 * time. The event itself is kept in an option (a rich cart outgrows Action
 * Scheduler's argument limit); the scheduled action only carries its key.
 * Should the first try have arrived after all, the gateway keeps one GA4 copy
 * per event id and Meta collapses its two by the same id.
 */
function nowera_capi_retry_later( string $body, int $attempt, ?string $key = null ): void {
	$delays = array( 2, 10, 30, 120, 360 ); // minutes
	$key    = $key ?: 'nowera_capi_retry_' . wp_generate_uuid4();
	if ( $attempt > count( $delays ) || ! function_exists( 'as_schedule_single_action' ) ) {
		delete_option( $key );
		error_log( '[nowera-capi] event dropped after ' . ( $attempt - 1 ) . ' retries' );
		return;
	}
	update_option( $key, $body, false );
	as_schedule_single_action( time() + $delays[ $attempt - 1 ] * MINUTE_IN_SECONDS, 'nowera_capi_retry_event', array( $key, $attempt ), 'nowera-capi' );
}

add_action( 'nowera_capi_retry_event', function ( $key, $attempt = 1 ) {
	$key = (string) $key;
	if ( 0 !== strpos( $key, 'nowera_capi_retry_' ) ) {
		return;
	}
	$body = get_option( $key );
	$data = is_string( $body ) ? json_decode( $body, true ) : null;
	// GA4 takes events up to 72 hours back; past two days a retry is not worth it.
	if ( ! is_array( $data ) || (int) ( $data['event_time'] ?? 0 ) < time() - 2 * DAY_IN_SECONDS ) {
		delete_option( $key );
		return;
	}
	$error = nowera_capi_deliver( $body );
	if ( null !== $error && nowera_capi_gateway_paused() ) {
		nowera_capi_retry_later( $body, (int) $attempt + 1, $key );
		return;
	}
	delete_option( $key );
}, 10, 2 );

/** Whether a recent failure paused sending. */
function nowera_capi_gateway_paused(): bool {
	return (int) get_transient( 'nowera_capi_pause' ) > time();
}

/** POST one event body to the gateway, signed. Null when it arrived, otherwise why not. */
function nowera_capi_deliver( string $body, string $path = '/s', int $timeout = 3 ): ?string {
	$s = nowera_capi_settings();
	if ( empty( $s['collector_host'] ) || empty( $s['ingest_secret'] ) ) {
		return 'plugin nemá vyplnený collector alebo kľúč';
	}
	if ( nowera_capi_gateway_paused() ) {
		return 'gateway nedávno neodpovedal, odosielanie je na minútu pozastavené';
	}
	// The time is signed with the body, so a captured request cannot be sent again later.
	$timestamp = (string) time();
	$response  = wp_remote_post( 'https://' . $s['collector_host'] . $path, array(
		'timeout'     => $timeout,
		'redirection' => 0,
		'headers'     => array(
			'Content-Type'    => 'application/json',
			'X-NWR-Timestamp' => $timestamp,
			'X-NWR-Signature' => hash_hmac( 'sha256', $timestamp . '.' . $body, $s['ingest_secret'] ),
			'X-NWR-Plugin'    => NOWERA_CAPI_VERSION,
		),
		'body'        => $body,
	) );
	$code = is_wp_error( $response ) ? 0 : (int) wp_remote_retrieve_response_code( $response );
	if ( $code >= 200 && $code < 300 ) {
		nowera_capi_note_status( null );
		return null;
	}
	$error = is_wp_error( $response )
		? $response->get_error_message()
		: 'HTTP ' . $code . ' ' . substr( wp_strip_all_tags( (string) wp_remote_retrieve_body( $response ) ), 0, 160 );
	// No answer, a server error or throttling: an outage, so pause. A 4xx is this
	// site's own problem (key, settings) and pausing would not fix it.
	if ( 0 === $code || $code >= 500 || 429 === $code ) {
		set_transient( 'nowera_capi_pause', time() + MINUTE_IN_SECONDS, MINUTE_IN_SECONDS );
	}
	nowera_capi_note_status( $error );
	error_log( '[nowera-capi] ' . $error );
	return $error;
}

/**
 * Remember how delivery goes, for the settings page. A success is written at
 * most every five minutes, so a busy shop does not write an option per event.
 */
function nowera_capi_note_status( ?string $error ): void {
	$status = get_option( 'nowera_capi_status', array() );
	$status = is_array( $status ) ? $status : array();
	if ( null === $error ) {
		if ( empty( $status['failing'] ) && ! empty( $status['ok_at'] ) && $status['ok_at'] > time() - 5 * MINUTE_IN_SECONDS ) {
			return;
		}
		$status['ok_at']   = time();
		$status['failing'] = false;
	} else {
		$status['error']    = $error;
		$status['error_at'] = time();
		$status['failing']  = true;
	}
	update_option( 'nowera_capi_status', $status, false );
}

/**
 * A Purchase the gateway did not take: the order forgets it was sent and the
 * after-payment job tries again from the order, later each time.
 */
function nowera_capi_purchase_failed( int $order_id, string $error ): void {
	static $done = array();
	$order = wc_get_order( $order_id );
	// An order's Lead and Purchase failing together are one failure, one retry.
	if ( ! $order || isset( $done[ $order_id ] ) ) {
		return;
	}
	$done[ $order_id ] = true;
	$attempt = (int) $order->get_meta( '_nowera_capi_purchase_retry' ) + 1;
	$delays  = array( 2, 10, 30, 60, 180 ); // minutes
	$order->delete_meta_data( '_nowera_capi_purchase_sent' );
	$order->update_meta_data( '_nowera_capi_purchase_retry', $attempt );
	$args = array( $order_id );
	if ( $attempt <= count( $delays ) && function_exists( 'as_schedule_single_action' ) && $order->get_meta( '_nowera_capi_ctx' ) ) {
		as_unschedule_action( 'nowera_capi_purchase_fallback', $args, 'nowera-capi' );
		as_schedule_single_action( time() + $delays[ $attempt - 1 ] * MINUTE_IN_SECONDS, 'nowera_capi_purchase_fallback', $args, 'nowera-capi' );
		$order->add_order_note( sprintf( 'Nowera CAPI: gateway Purchase neprijal (%s), skúsi sa znova o %d min.', $error, $delays[ $attempt - 1 ] ) );
	} else {
		$order->add_order_note( 'Nowera CAPI: Purchase sa nepodarilo doručiť ani po opakovaní: ' . $error );
	}
	$order->save();
}

/** Plain-language outcome of a Purchase, written to the order so it can be checked later. */
function nowera_capi_record_outcome( \WC_Order $order, string $outcome, bool $after_payment = false ): void {
	$what  = nowera_capi_plan_label( $order );
	$notes = array(
		'marketing'      => $what . ' odoslaný do Mety aj GA4 (súhlas: marketing).',
		'statistics'     => $what . ' odoslaný len pre štatistiku — bez marketingového súhlasu ho Meta nedostane.',
		'none'           => $what . ' neodoslaný — návštevník nedal súhlas s cookies.',
		'not_configured' => $what . ' neodoslaný — plugin nemá vyplnený collector alebo kľúč.',
		'ledger'         => 'Do Mety ani GA4 sa neposiela (nulová suma alebo obnovenie predplatného) — objednávka je len v evidencii.',
	);
	$note = $notes[ $outcome ] ?? $outcome;
	if ( $after_payment ) {
		$note = 'Po potvrdení platby (zákazník sa nevrátil na web): ' . $note;
	}
	// A reloaded thank-you page without consent would write the same note again.
	$same = $order->get_meta( '_nowera_capi_purchase_consent' ) === $outcome && ! $after_payment;
	$order->update_meta_data( '_nowera_capi_purchase_consent', $outcome );
	if ( ! $same ) {
		$order->add_order_note( 'Nowera CAPI: ' . $note );
	}
}

/**
 * Keep what the checkout request knew about the buyer. When the payment gateway
 * confirms the order later and the buyer never returns to the thank-you page,
 * that confirmation arrives without the buyer's cookies — this is all we have.
 * Marketing identifiers are kept only if the buyer allowed marketing.
 */
function nowera_capi_remember_checkout_context( \WC_Order $order ): void {
	if ( $order->get_meta( '_nowera_capi_ctx' ) ) {
		return;
	}
	$ctx  = nowera_capi_request_context();
	$keep = array(
		'marketing'     => (bool) $ctx['marketing'],
		'statistics'    => (bool) $ctx['statistics'],
		'ga_client_id'  => $ctx['ga_client_id'],
		'ga_session_id' => $ctx['ga_session_id'],
	);
	if ( $ctx['marketing'] ) {
		$keep['fbp']     = $ctx['fbp'];
		$keep['fbc']     = $ctx['fbc'];
		$keep['visitor'] = nowera_capi_visitor_id();
	}
	$order->update_meta_data( '_nowera_capi_ctx', $keep );
}

/** Purchase custom_data, shared by the thank-you page and the after-payment path. */
/** The items' worth without VAT and shipping, after discounts: GA4's purchase value. */
function nowera_capi_order_net( \WC_Order $order ): float {
	return round( (float) $order->get_subtotal() - (float) $order->get_discount_total(), wc_get_price_decimals() );
}

/** The share of an amount paid on this order that GA4 counts (its items, no VAT, no shipping). */
function nowera_capi_net_share( \WC_Order $order, float $amount ): float {
	$total = (float) $order->get_total();
	return $total > 0 ? round( $amount * nowera_capi_order_net( $order ) / $total, wc_get_price_decimals() ) : $amount;
}

/** The order's lines as items. */
function nowera_capi_order_items( \WC_Order $order ): array {
	$items = array();
	foreach ( $order->get_items() as $line ) {
		if ( $line instanceof \WC_Order_Item_Product ) {
			$items[] = nowera_capi_order_item( $line, $order );
		}
	}
	return $items;
}

/* -------------------------------------------------------------------------
 * What an order is, and how it is reported
 * ---------------------------------------------------------------------- */

/**
 * What one order line sells: a product unless an adapter (adapters/*.php) knows
 * better — a booking, a gift card, a subscription. A refund's line is what the
 * line it gives back was.
 */
function nowera_capi_line_kind( \WC_Order_Item_Product $line, \WC_Abstract_Order $order ): string {
	$origin = (int) $line->get_meta( '_refunded_item_id' );
	if ( $origin ) {
		$original = \WC_Order_Factory::get_order_item( $origin );
		if ( $original instanceof \WC_Order_Item_Product ) {
			$line = $original;
		}
	}
	$kind = (string) apply_filters( 'nowera_capi_line_kind', 'product', $line, $order );
	return preg_match( '/^[a-z][a-z0-9_]{0,29}$/', $kind ) ? $kind : 'product';
}

/** Kinds that are a lead (an appointment booked), not a sale of goods. */
function nowera_capi_lead_kinds(): array {
	return (array) apply_filters( 'nowera_capi_lead_kinds', array( 'booking' ) );
}

/** The part of an order settled with a voucher (a gift card), not with money. */
function nowera_capi_order_tender( \WC_Order $order ): float {
	return max( 0.0, round( (float) apply_filters( 'nowera_capi_order_tender', 0.0, $order ), wc_get_price_decimals() ) );
}

/**
 * How an order is reported. A booking is a Lead, whether paid or free; goods
 * are a Purchase of the money actually paid for them (a gift card was counted
 * when it was sold, so what it settles later is not counted again); an order
 * that cost nothing and a subscription's renewal are kept in the order list
 * only. Amounts are split by what the lines are worth.
 *
 * Returns kind (of the order: one kind, 'mixed' or 'renewal'), expect (the
 * events to send), paid, tender, goods, parts (money paid per kind) and the
 * lead / purchase / subscribe figures.
 */
function nowera_capi_order_plan( \WC_Order $order ): array {
	$dp      = wc_get_price_decimals();
	$total   = (float) $order->get_total();
	$tender  = nowera_capi_order_tender( $order );
	$base    = $total + $tender; // what was sold, however it was settled
	$cash    = $base > 0 ? $total / $base : 0.0;
	$leads   = nowera_capi_lead_kinds();
	$renewal = (bool) apply_filters( 'nowera_capi_order_renewal', false, $order );

	$gross = array(); // per kind, with VAT, after coupons
	$net   = array();
	$tax   = array();
	$qty   = array();
	$names = array();
	foreach ( $order->get_items() as $line ) {
		if ( ! $line instanceof \WC_Order_Item_Product ) {
			continue;
		}
		$kind           = nowera_capi_line_kind( $line, $order );
		$gross[ $kind ] = ( $gross[ $kind ] ?? 0 ) + (float) $line->get_total() + (float) $line->get_total_tax();
		$net[ $kind ]   = ( $net[ $kind ] ?? 0 ) + (float) $line->get_total();
		$tax[ $kind ]   = ( $tax[ $kind ] ?? 0 ) + (float) $line->get_total_tax();
		$qty[ $kind ]   = ( $qty[ $kind ] ?? 0 ) + (int) $line->get_quantity();
		$names[ $kind ][] = (string) apply_filters( 'nowera_capi_line_name', $line->get_name(), $line, $order );
	}

	$parts = array();
	foreach ( $gross as $kind => $amount ) {
		$parts[ $kind ] = round( $amount * $cash, $dp );
	}
	// Shipping and fees: money paid for none of the lines.
	$rest = round( $total - array_sum( $parts ), $dp );
	if ( abs( $rest ) >= 0.01 ) {
		$parts['other'] = $rest;
	}

	$lead_kinds = array_values( array_intersect( array_keys( $gross ), $leads ) );
	$lead_value = 0.0;
	foreach ( $lead_kinds as $kind ) {
		$lead_value += $parts[ $kind ];
	}
	$lead_value = round( $lead_value, $dp );
	// A paid booking counts twice, as a Lead and as part of the order's Purchase,
	// so a campaign or a report can go by either. A site that wants bookings as
	// leads only says so through this filter.
	$also_sale      = (bool) apply_filters( 'nowera_capi_lead_is_purchase', true, $order );
	$purchase_kinds = $also_sale ? array_keys( $gross ) : array_values( array_diff( array_keys( $gross ), $leads ) );
	// An order without a single product line (fees only) is still a sale.
	$purchase       = $purchase_kinds || ! $lead_kinds;
	$purchase_value = $purchase ? round( max( 0, $also_sale ? $total : $total - $lead_value ), $dp ) : 0.0;

	$expect = array();
	if ( ! $renewal ) {
		if ( $lead_kinds ) {
			$expect[] = 'Lead';
		}
		if ( $purchase_value > 0 ) {
			$expect[] = 'Purchase';
			if ( ( $parts['subscription'] ?? 0 ) > 0 ) {
				$expect[] = 'Subscribe';
			}
		}
	}

	$kinds = array_keys( $gross );
	$plan  = array(
		'kind'    => $renewal ? 'renewal' : ( 1 === count( $kinds ) ? $kinds[0] : ( $kinds ? 'mixed' : 'product' ) ),
		'expect'  => $expect,
		'paid'    => round( $total, $dp ),
		'tender'  => $tender,
		'goods'   => round( $base, $dp ),
		'parts'   => $parts,
		'cash'    => $cash,
		// The Purchase is not simply the whole order.
		'split'   => ( $lead_kinds && ! $also_sale ) || $tender > 0,
		'lead'    => null,
		'purchase' => null,
		'subscribe' => null,
	);
	if ( $lead_kinds ) {
		$lead_names = array();
		$count      = 0;
		foreach ( $lead_kinds as $kind ) {
			$lead_names = array_merge( $lead_names, $names[ $kind ] );
			$count     += $qty[ $kind ];
		}
		$plan['lead'] = array(
			'value' => $lead_value,
			'kind'  => $lead_kinds[0],
			'names' => array_values( array_unique( array_filter( $lead_names ) ) ),
			'count' => $count,
		);
	}
	if ( $purchase ) {
		$p_net = 0.0;
		$p_tax = 0.0;
		$p_qty = 0;
		foreach ( $purchase_kinds as $kind ) {
			$p_net += $net[ $kind ];
			$p_tax += $tax[ $kind ];
			$p_qty += $qty[ $kind ];
		}
		$plan['purchase'] = array(
			'value'     => $purchase_value,
			'value_net' => round( $p_net * $cash, $dp ),
			'tax'       => round( ( $p_tax + (float) $order->get_shipping_tax() ) * $cash, $dp ),
			'shipping'  => round( (float) $order->get_shipping_total() * $cash, $dp ),
			'num_items' => $p_qty,
			'kinds'     => $purchase_kinds,
			// The share of the order's money a refund of "an amount" takes back from GA4.
			'share'     => $total > 0 ? $purchase_value / $total : 0.0,
		);
	}
	if ( in_array( 'Subscribe', $expect, true ) ) {
		$plan['subscribe'] = array(
			'value' => $parts['subscription'],
			'names' => array_values( array_unique( array_filter( $names['subscription'] ) ) ),
		);
	}
	return $plan;
}

/** The plan an order was reported under, or null for one reported before plans existed. */
function nowera_capi_reported_plan( \WC_Order $order ): ?array {
	$stored = $order->get_meta( '_nowera_capi_plan' );
	return is_array( $stored ) && isset( $stored['expect'] ) && is_array( $stored['expect'] ) ? $stored : null;
}

/**
 * The plan a refund or a cancellation goes by: the one the order was reported
 * under; for an order not reported yet (refunded before its buyer returned or
 * its payment's confirmation was worked off) the one it would be reported
 * under; null for an order reported before plans existed — a plain Purchase.
 */
function nowera_capi_refund_plan( \WC_Order $order ): ?array {
	$plan = nowera_capi_reported_plan( $order );
	if ( $plan || $order->get_meta( '_nowera_capi_purchase_sent' ) ) {
		return $plan;
	}
	$now = nowera_capi_order_plan( $order );
	return array(
		'expect' => $now['expect'],
		'share'  => $now['purchase']['share'] ?? 0.0,
		'net'    => $now['split'] ? ( $now['purchase']['value_net'] ?? 0.0 ) : nowera_capi_order_net( $order ),
		'split'  => $now['split'],
		'cash'   => $now['cash'],
		'sold'   => $now['purchase']['kinds'] ?? array(),
	);
}

function nowera_capi_purchase_data( \WC_Order $order, ?array $plan = null ): array {
	$plan     = $plan ?? nowera_capi_order_plan( $order );
	$leads    = nowera_capi_lead_kinds();
	$sold     = $plan['purchase']['kinds'] ?? array();
	$contents = array();
	foreach ( $order->get_items() as $line ) {
		$kind = $line instanceof \WC_Order_Item_Product ? nowera_capi_line_kind( $line, $order ) : null;
		// Only what the Purchase covers (a booking too, unless the site counts bookings as leads only).
		if ( $kind && in_array( $kind, $sold, true ) ) {
			$item = nowera_capi_order_item( $line, $order );
			// A booking's line is the booking plugin's one product: name it after what was booked.
			if ( in_array( $kind, $leads, true ) ) {
				$item['item_name'] = (string) apply_filters( 'nowera_capi_line_name', $item['item_name'], $line, $order );
			}
			// Part paid with a gift card: each item at the share paid in money, so the
			// items add up to the purchase's value.
			if ( $plan['tender'] > 0 ) {
				foreach ( array( 'item_price', 'price_net', 'discount' ) as $key ) {
					if ( isset( $item[ $key ] ) ) {
						$item[ $key ] = round( $item[ $key ] * $plan['cash'], wc_get_price_decimals() );
					}
				}
			}
			$contents[] = $item;
		}
	}

	// value is what the customer paid, VAT and shipping included (Meta, and the
	// shop's own reports); GA4 counts value_net — the items without VAT and
	// shipping, as Google defines it — with tax and shipping on their own.
	$custom_data = array(
		'value'        => (float) $order->get_total(),
		'value_net'    => nowera_capi_order_net( $order ),
		'currency'     => $order->get_currency(),
		'order_id'     => $order->get_id(),
		'content_ids'  => array_column( $contents, 'id' ),
		'contents'     => $contents,
		'content_type' => 'product',
		'num_items'    => $order->get_item_count(),
		'tax'          => round( (float) $order->get_total_tax(), wc_get_price_decimals() ),
		'shipping'     => round( (float) $order->get_shipping_total(), wc_get_price_decimals() ),
	);
	// Part of the order is a lead, or part was settled with a gift card: only the
	// money paid for the goods counts.
	if ( $plan['split'] && $plan['purchase'] ) {
		$custom_data = array_merge( $custom_data, array_intersect_key( $plan['purchase'], array_flip( array( 'value', 'value_net', 'tax', 'shipping', 'num_items' ) ) ) );
	}
	// Gift cards and subscriptions apart from goods, for a conversion of their own.
	$kinds    = $plan['purchase']['kinds'] ?? array();
	$category = 1 === count( $kinds ) ? $kinds[0] : ( $kinds ? 'mixed' : 'product' );
	if ( 'product' !== $category ) {
		$custom_data['content_category'] = $category;
	}
	if ( $order->get_coupon_codes() ) {
		$custom_data['coupon'] = implode( ',', $order->get_coupon_codes() );
	}
	// New or returning buyer, for campaigns that optimise for new customers.
	$segment = nowera_capi_customer_segment( $order );
	if ( $segment ) {
		$custom_data['customer_segmentation'] = $segment;
	}
	return $custom_data;
}

/** The names of what was booked or subscribed to, as one label. */
function nowera_capi_names_label( array $names ): string {
	return mb_substr( wp_strip_all_tags( implode( ' + ', $names ) ), 0, 100 );
}

/**
 * Sends everything an order's plan expects — a Lead for its bookings, a
 * Purchase for its goods, a Subscribe for a new subscription — and remembers
 * the plan on the order, so a later refund knows what there is to take back.
 * Returns what nowera_capi_send does, or 'ledger' when the order is reported to
 * nobody (it cost nothing, or it renews a subscription) and only kept in the
 * order list. `$on_page` adds the browser halves (the thank-you page).
 */
function nowera_capi_report_order( \WC_Order $order, array $user, ?array $ctx = null, bool $on_page = false ): string {
	$plan = nowera_capi_order_plan( $order );
	$order->update_meta_data( '_nowera_capi_plan', array(
		'kind'   => $plan['kind'],
		'expect' => $plan['expect'],
		// For a refund later: the Purchase's share of the order's money, what GA4
		// was told it is worth, and whether it was the whole order as it stands.
		'share'  => $plan['purchase']['share'] ?? 0.0,
		'net'    => $plan['split'] ? ( $plan['purchase']['value_net'] ?? 0.0 ) : nowera_capi_order_net( $order ),
		'split'  => $plan['split'],
		'cash'   => $plan['cash'],
		// What the Purchase covered: since 1.3.2 a paid booking too.
		'sold'   => $plan['purchase']['kinds'] ?? array(),
	) );
	if ( ! $plan['expect'] ) {
		return 'ledger';
	}
	$url     = nowera_capi_order_url( $order );
	$id      = $order->get_id();
	$events  = array();
	if ( in_array( 'Lead', $plan['expect'], true ) ) {
		$events[] = array( 'Lead', 'book-' . $id, array(
			'value'            => $plan['lead']['value'],
			'currency'         => $order->get_currency(),
			'content_name'     => nowera_capi_names_label( $plan['lead']['names'] ),
			'content_category' => $plan['lead']['kind'],
			'num_items'        => $plan['lead']['count'],
		) );
	}
	if ( in_array( 'Purchase', $plan['expect'], true ) ) {
		$events[] = array( 'Purchase', 'ord-' . $id, nowera_capi_purchase_data( $order, $plan ) );
	}
	if ( in_array( 'Subscribe', $plan['expect'], true ) ) {
		$events[] = array( 'Subscribe', 'sub-' . $id, array(
			'value'        => $plan['subscribe']['value'],
			'currency'     => $order->get_currency(),
			'content_name' => nowera_capi_names_label( $plan['subscribe']['names'] ),
		) );
	}
	$outcome = 'none';
	foreach ( $events as $event ) {
		$outcome = nowera_capi_send( $event[0], $event[1], $user, $event[2], $url, $ctx, $id );
		if ( $on_page ) {
			nowera_capi_browser_leg( $event[0], $event[1], $event[2] );
		}
	}
	return $outcome;
}

/** What an order's plan sends, in words for the order note. */
function nowera_capi_plan_label( \WC_Order $order ): string {
	$plan = nowera_capi_reported_plan( $order );
	return $plan && $plan['expect'] ? implode( ' + ', $plan['expect'] ) : 'Purchase';
}

/**
 * The browser half of a server event: same event_id and same products, so Meta
 * collapses the two into one conversion and the pixel's own identifiers (fbp,
 * fbc, user agent) count towards the match.
 */
function nowera_capi_browser_leg( string $event_name, string $event_id, array $custom_data ): void {
	add_action( 'wp_footer', function () use ( $event_name, $event_id, $custom_data ) {
		printf(
			'<script>window.nwr=window.nwr||function(){(window.nwr.q=window.nwr.q||[]).push(arguments)};' .
			'window.nwr("track",%s,%s,{eventID:%s});</script>' . "\n",
			wp_json_encode( $event_name ),
			wp_json_encode( $custom_data ),
			wp_json_encode( $event_id )
		);
	} );
}

/** Identity fields we can read from the logged-in user or a Woo order. */
function nowera_capi_user_from_order( \WC_Order $order ): array {
	return array_filter( array(
		'em'          => $order->get_billing_email(),
		'ph'          => $order->get_billing_phone(),
		'fn'          => $order->get_billing_first_name(),
		'ln'          => $order->get_billing_last_name(),
		'ct'          => $order->get_billing_city(),
		'zp'          => $order->get_billing_postcode(),
		'country'     => $order->get_billing_country(),
		'external_id' => $order->get_customer_id()
			? (string) $order->get_customer_id()
			: (string) nowera_capi_visitor_id(),
		'account'     => $order->get_customer_id() ? (string) $order->get_customer_id() : '',
	) );
}

/* -------------------------------------------------------------------------
 * Cart changes, registration, forms
 * ---------------------------------------------------------------------- */

/**
 * Whether a cart change comes from the shopper: not cron, not the admin, not
 * the checkout turning the cart into an order, not WooCommerce loading a cart.
 * Other cases can be ruled out with the filter.
 */
function nowera_capi_shopper_cart_change(): bool {
	$shopper = ! wp_doing_cron()
		&& ! ( is_admin() && ! wp_doing_ajax() )
		&& ! did_action( 'woocommerce_checkout_process' )
		&& ! doing_action( 'woocommerce_cart_loaded_from_session' )
		&& ! doing_action( 'woocommerce_load_cart_from_session' );
	return (bool) apply_filters( 'nowera_capi_shopper_cart_change', $shopper );
}

/** A line taken out of the cart (GA4 remove_from_cart; Meta has no such event). */
function nowera_capi_removed( \WC_Product $product, int $quantity ): void {
	if ( $quantity < 1 || ! nowera_capi_shopper_cart_change() ) {
		return;
	}
	$item = nowera_capi_item( $product, $quantity );
	nowera_capi_send( 'RemoveFromCart', wp_generate_uuid4(), nowera_capi_current_user(), array(
		'value'       => round( $item['item_price'] * $quantity, wc_get_price_decimals() ),
		'value_net'   => round( $item['price_net'] * $quantity, wc_get_price_decimals() ),
		'currency'    => get_woocommerce_currency(),
		'content_ids' => array( $item['id'] ),
		'contents'    => array( $item ),
	), wc_get_cart_url() );
}

// Runs before the line leaves the cart, so it can still be read.
add_action( 'woocommerce_remove_cart_item', function ( $key, $cart ) {
	$line = $cart->get_cart_item( $key );
	if ( ! empty( $line['data'] ) && $line['data'] instanceof \WC_Product ) {
		nowera_capi_removed( $line['data'], (int) $line['quantity'] );
	}
}, 10, 2 );

// A lower quantity takes some of a line out; zero goes through the removal above.
add_action( 'woocommerce_after_cart_item_quantity_update', function ( $key, $quantity, $old_quantity, $cart ) {
	$line = $cart->get_cart_item( $key );
	if ( (int) $quantity < (int) $old_quantity && ! empty( $line['data'] ) && $line['data'] instanceof \WC_Product ) {
		nowera_capi_removed( $line['data'], (int) $old_quantity - (int) $quantity );
	}
}, 10, 4 );

/**
 * A customer account created on the shop itself (My Account or at checkout),
 * once per account. Users made by an administrator or an import do not pass here.
 */
add_action( 'woocommerce_created_customer', function ( $customer_id, $data = array() ) {
	if ( get_user_meta( $customer_id, '_nowera_capi_registered', true ) ) {
		return;
	}
	update_user_meta( $customer_id, '_nowera_capi_registered', time() );
	$user = get_userdata( $customer_id );
	nowera_capi_send( 'CompleteRegistration', 'reg-' . $customer_id, array_filter( array(
		'em'          => $user ? $user->user_email : ( $data['user_email'] ?? '' ),
		'fn'          => $user ? $user->first_name : '',
		'ln'          => $user ? $user->last_name : '',
		'external_id' => (string) $customer_id,
		'account'     => (string) $customer_id,
	) ), array(
		'method'   => function_exists( 'is_checkout' ) && is_checkout() ? 'checkout' : 'account',
		'currency' => get_woocommerce_currency(),
	) );
}, 10, 2 );

/**
 * A form sent successfully. Which forms count is chosen per form in the
 * settings — an enquiry or a newsletter signup, both reported as Lead (Meta's
 * Subscribe means a paid subscription) with the kind in content_category, so
 * each can be its own conversion. The forms the site has used are listed there
 * once they were sent. Nothing counts by default: a search box is no conversion.
 */
function nowera_capi_form_sent( string $plugin, string $form_id, string $form_name, array $values ): void {
	$key  = $plugin . ':' . $form_id;
	$seen = get_option( 'nowera_capi_forms_seen', array() );
	$seen = is_array( $seen ) ? $seen : array();
	if ( ! isset( $seen[ $key ] ) || ( $seen[ $key ]['at'] ?? 0 ) < time() - DAY_IN_SECONDS ) {
		$seen[ $key ] = array( 'name' => mb_substr( wp_strip_all_tags( $form_name ), 0, 80 ), 'at' => time() );
		uasort( $seen, function ( $a, $b ) { return $b['at'] <=> $a['at']; } );
		update_option( 'nowera_capi_forms_seen', array_slice( $seen, 0, 40, true ), false );
	}
	$forms = nowera_capi_settings()['forms'];
	$role  = is_array( $forms ) ? ( $forms[ $key ] ?? '' ) : '';
	$kind  = array( 'lead' => 'enquiry', 'newsletter' => 'newsletter' )[ $role ] ?? null;
	if ( ! $kind ) {
		return;
	}
	$email = '';
	$phone = '';
	foreach ( $values as $name => $value ) {
		if ( ! is_scalar( $value ) ) {
			continue;
		}
		$value = trim( (string) $value );
		if ( '' === $email && is_email( $value ) ) {
			$email = $value;
		} elseif ( '' === $phone && preg_match( '/phone|tel|mobil/i', (string) $name ) && strlen( preg_replace( '/\D/', '', $value ) ) >= 8 ) {
			$phone = $value;
		}
	}
	$user = array_merge( nowera_capi_current_user(), array_filter( array( 'em' => $email, 'ph' => $phone ) ) );
	// Sent from the form's own request (often AJAX): the page it was on is the referrer.
	// Without its query: a prefilled form field could ride along in it.
	$page = wp_get_referer();
	$page = $page ? strtok( strtok( $page, '#' ), '?' ) : home_url( '/' );
	nowera_capi_send( 'Lead', 'form-' . wp_generate_uuid4(), $user, array(
		'content_name'     => mb_substr( wp_strip_all_tags( $form_name ), 0, 80 ),
		'content_category' => $kind,
		'form_id'          => $key,
	), $page );
}

// Contact Form 7: after the mail went out (spam already filtered).
add_action( 'wpcf7_mail_sent', function ( $form ) {
	$submission = class_exists( 'WPCF7_Submission' ) ? \WPCF7_Submission::get_instance() : null;
	nowera_capi_form_sent( 'cf7', (string) $form->id(), (string) $form->title(), $submission ? (array) $submission->get_posted_data() : array() );
} );

// Forminator: AJAX submissions save the entry, page-reload ones finish the
// submit handler; either counts, once per form and request.
function nowera_capi_forminator( $form_id, $response = array() ): void {
	static $done = array();
	if ( isset( $done[ $form_id ] ) || ( is_array( $response ) && isset( $response['success'] ) && ! $response['success'] ) ) {
		return;
	}
	$done[ $form_id ] = true;
	$title = function_exists( 'forminator_get_form_name' ) ? forminator_get_form_name( $form_id ) : get_the_title( $form_id );
	nowera_capi_form_sent( 'forminator', (string) $form_id, (string) $title, wp_unslash( $_POST ) ); // phpcs:ignore WordPress.Security.NonceVerification
}
add_action( 'forminator_form_after_save_entry', 'nowera_capi_forminator', 10, 2 );
add_action( 'forminator_form_after_handle_submit', 'nowera_capi_forminator', 10, 2 );

// Elementor Pro forms.
add_action( 'elementor_pro/forms/new_record', function ( $record ) {
	$values = array();
	foreach ( (array) $record->get( 'fields' ) as $id => $field ) {
		$values[ ( $field['type'] ?? '' ) . '_' . $id ] = $field['value'] ?? '';
	}
	nowera_capi_form_sent( 'elementor', (string) $record->get_form_settings( 'id' ), (string) $record->get_form_settings( 'form_name' ), $values );
} );

// WPForms.
add_action( 'wpforms_process_complete', function ( $fields, $entry, $form_data ) {
	$values = array();
	foreach ( (array) $fields as $id => $field ) {
		$values[ ( $field['type'] ?? '' ) . '_' . $id ] = $field['value'] ?? '';
	}
	nowera_capi_form_sent( 'wpforms', (string) ( $form_data['id'] ?? '' ), (string) ( $form_data['settings']['form_title'] ?? '' ), $values );
}, 10, 3 );

// Fluent Forms.
add_action( 'fluentform/submission_inserted', function ( $entry_id, $data, $form ) {
	nowera_capi_form_sent( 'fluent', (string) ( $form->id ?? '' ), (string) ( $form->title ?? '' ), (array) $data );
}, 10, 3 );

// Gravity Forms.
add_action( 'gform_after_submission', function ( $entry, $form ) {
	$values = array();
	foreach ( (array) ( $form['fields'] ?? array() ) as $field ) {
		$id                          = is_object( $field ) ? $field->id : ( $field['id'] ?? '' );
		$type                        = is_object( $field ) ? $field->type : ( $field['type'] ?? '' );
		$values[ $type . '_' . $id ] = $entry[ (string) $id ] ?? '';
	}
	nowera_capi_form_sent( 'gravity', (string) ( $form['id'] ?? '' ), (string) ( $form['title'] ?? '' ), $values );
}, 10, 2 );

// Bricks forms: runs when the form has "Custom" among its actions.
add_action( 'bricks/form/custom_action', function ( $form ) {
	// Bricksforge Pro Forms fire this hook too from their own "Custom" action;
	// those count once, in the Bricksforge handler below.
	if ( did_action( 'bricksforge/pro_forms/before_submit' ) || is_a( $form, 'Bricksforge\ProForms\Actions\Base' ) ) {
		return;
	}
	$settings = method_exists( $form, 'get_settings' ) ? (array) $form->get_settings() : array();
	$fields   = method_exists( $form, 'get_fields' ) ? (array) $form->get_fields() : array();
	nowera_capi_form_sent( 'bricks', (string) ( $fields['formId'] ?? '' ), (string) ( $settings['formName'] ?? ( $fields['formId'] ?? 'Bricks' ) ), $fields );
} );

/**
 * Bricksforge Pro Forms (element brf-pro-forms), whatever actions the form has.
 * after_submit runs once every action is done; a failed validation, captcha,
 * honeypot, file check or duplicate ends the request before it. An action that
 * reported an error makes the visitor see an error, so that is no lead either.
 * Payment forms (Stripe, Mollie) return before it and finish in a webhook:
 * not counted.
 *
 * The form is keyed by the post or template that holds the element plus the
 * element's id, so a form in a footer template stays one form on every page.
 */
add_action( 'bricksforge/pro_forms/after_submit', function ( $form_data, $return_values = array() ) {
	static $done = false;
	if ( $done || ! is_array( $form_data ) || ( is_array( $return_values ) && ! empty( $return_values['results']['error'] ) ) ) {
		return;
	}
	// Resolved in Bricksforge's own order: formId (data-script-id, a random one
	// inside query loops), then formIdFallback (data-element-id). A fallback that
	// names another form must not take this submission's place.
	$ids = array();
	foreach ( array( 'formId', 'formIdFallback' ) as $param ) {
		$id = substr( preg_replace( '/[^A-Za-z0-9_-]/', '', is_scalar( $form_data[ $param ] ?? null ) ? (string) $form_data[ $param ] : '' ), 0, 40 );
		if ( '' !== $id && ! in_array( $id, $ids, true ) ) {
			$ids[] = $id;
		}
	}
	if ( ! $ids ) {
		return;
	}
	$done    = true;
	$post_id = absint( $form_data['postId'] ?? 0 );
	$owner   = $post_id;
	$element = '';
	$found   = null;
	$all     = array();
	if ( class_exists( '\Bricks\Helpers' ) && method_exists( '\Bricks\Helpers', 'get_element_data' ) ) {
		foreach ( $ids as $id ) {
			$data = \Bricks\Helpers::get_element_data( $post_id, $id );
			if ( is_array( $data ) && is_array( $data['element'] ?? null ) && 'brf-pro-forms' === ( $data['element']['name'] ?? '' ) ) {
				$element = $id;
				$found   = $data['element'];
				$all     = is_array( $data['elements'] ?? null ) ? $data['elements'] : array();
				$owner   = is_numeric( $data['source_id'] ?? null ) && (int) $data['source_id'] > 0 ? (int) $data['source_id'] : ( 'component' === ( $data['source_id'] ?? '' ) ? 'c' : $post_id );
				break;
			}
		}
	}
	// Not found in the page or its templates: the element id as sent, on its page.
	if ( '' === $element ) {
		$element = end( $ids );
	}
	// The title the site gave it: Bricksforge's "Form Title" (its submissions
	// table), else the element's name in the structure panel. Never a dynamic tag:
	// the name goes to Meta, it must not carry what a visitor typed or who they are.
	$title = '';
	foreach ( array( $found['settings']['submission_form_title'] ?? '', $found['label'] ?? '' ) as $candidate ) {
		$candidate = is_string( $candidate ) ? trim( wp_strip_all_tags( $candidate ) ) : '';
		if ( '' !== $candidate && false === strpos( $candidate, '{' ) ) {
			$title = $candidate;
			break;
		}
	}
	if ( '' === $title ) {
		$page  = is_int( $owner ) && $owner > 0 ? get_the_title( $owner ) : '';
		$title = 'Pro Forms' . ( '' !== $page ? ' – ' . $page : '' );
	}
	// Posted as form-field-<id>, id being the field's custom ID or its element id
	// (nested field elements), or the row id of the older "fields" repeater.
	$types = array();
	foreach ( (array) ( $found['settings']['fields'] ?? array() ) as $field ) {
		if ( is_array( $field ) && ! empty( $field['id'] ) && is_string( $field['type'] ?? null ) ) {
			$types[ (string) $field['id'] ] = $field['type'];
		}
	}
	foreach ( $all as $el ) {
		if ( is_array( $el ) && 0 === strpos( (string) ( $el['name'] ?? '' ), 'brf-pro-forms-field-' ) ) {
			$id = (string) ( ( $el['settings']['id'] ?? '' ) ?: ( $el['id'] ?? '' ) );
			if ( '' !== $id ) {
				$types[ $id ] = substr( (string) $el['name'], 20 );
			}
		}
	}
	$declared = in_array( 'email', $types, true );
	$emails   = array();
	$values   = array();
	foreach ( $form_data as $name => $value ) {
		if ( 0 !== strpos( (string) $name, 'form-field-' ) || ! is_scalar( $value ) ) {
			continue;
		}
		$id   = substr( (string) $name, 11 );
		$type = $types[ $id ] ?? 'field';
		// E-mail fields first: a hidden field may hold some other address. When the
		// form declares an e-mail field, only it and phone fields are read, so an
		// address written into the message never stands in for an empty one.
		if ( 'email' === $type ) {
			$emails[ $type . '_' . $id ] = $value;
		} elseif ( ! $declared || 'tel' === $type || preg_match( '/phone|tel|mobil/i', $id ) ) {
			$values[ $type . '_' . $id ] = $value;
		}
	}
	nowera_capi_form_sent( 'bricksforge', $owner . '-' . $element, $title, $emails + $values );
}, 10, 2 );

/* -------------------------------------------------------------------------
 * Adapters: what other plugins' orders are
 * ---------------------------------------------------------------------- */

// Each one only answers the filters above for data its own plugin wrote, so
// loading them all costs nothing on a site without that plugin.
foreach ( array( 'amelia', 'wpsubscription', 'pw-gift-cards' ) as $nowera_capi_adapter ) {
	$nowera_capi_adapter = __DIR__ . '/adapters/' . $nowera_capi_adapter . '.php';
	if ( is_readable( $nowera_capi_adapter ) ) {
		require_once $nowera_capi_adapter;
	}
}
unset( $nowera_capi_adapter );

/* -------------------------------------------------------------------------
 * Order list for the completeness check
 * ---------------------------------------------------------------------- */

/**
 * Every hour the orders that changed in the last three days (new, paid,
 * cancelled, refunded) go to the gateway, signed like the events: id, the day it
 * was created (shop time zone), status, times, what it is (goods, a booking, a
 * gift card, a subscription), its amounts and what this plugin did with it. No
 * contact data. The gateway sets them against the events it received and
 * delivered, so a shop can see that every order with consent arrived — and why
 * the others did not count — and keeps them as the order list its reports read.
 * Read and sent 200 at a time.
 */
const NOWERA_CAPI_AUDIT_EVERY = HOUR_IN_SECONDS;
/** How far back the first list after an update reaches, so the reports have a history. */
const NOWERA_CAPI_BACKFILL_DAYS = 90;

add_action( 'action_scheduler_init', function () {
	$s = nowera_capi_settings();
	if ( empty( $s['collector_host'] ) || empty( $s['ingest_secret'] ) || ! function_exists( 'as_has_scheduled_action' ) ) {
		return;
	}
	// The list used to go every six hours: put it on the current rhythm once.
	if ( (int) get_option( 'nowera_capi_audit_every' ) !== NOWERA_CAPI_AUDIT_EVERY ) {
		as_unschedule_all_actions( 'nowera_capi_audit', array(), 'nowera-capi' );
		update_option( 'nowera_capi_audit_every', NOWERA_CAPI_AUDIT_EVERY, false );
	}
	if ( ! as_has_scheduled_action( 'nowera_capi_audit', array(), 'nowera-capi' ) ) {
		as_schedule_recurring_action( time() + 10 * MINUTE_IN_SECONDS, NOWERA_CAPI_AUDIT_EVERY, 'nowera_capi_audit', array(), 'nowera-capi' );
	}
	// Once per version of the list: the older orders, described the new way.
	if ( get_option( 'nowera_capi_backfill' ) !== '1.3' && ! as_has_scheduled_action( 'nowera_capi_audit_backfill', array(), 'nowera-capi' ) ) {
		as_schedule_single_action( time() + 2 * MINUTE_IN_SECONDS, 'nowera_capi_audit_backfill', array(), 'nowera-capi' );
	}
} );

add_action( 'nowera_capi_audit', function () {
	nowera_capi_send_audit();
} );

add_action( 'nowera_capi_audit_backfill', function ( $page = 1, $attempt = 1 ) {
	// Marked first, so page loads do not queue it again while it runs.
	update_option( 'nowera_capi_backfill', '1.3', false );
	$page = max( 1, (int) $page );
	// A busy shop's quarter of a year does not fit one run: twenty seconds at a
	// time, the next run takes over where this one stopped.
	$next = nowera_capi_send_audit( NOWERA_CAPI_BACKFILL_DAYS, $page, 20 );
	if ( ! function_exists( 'as_schedule_single_action' ) ) {
		return;
	}
	if ( is_int( $next ) ) {
		as_schedule_single_action( time() + MINUTE_IN_SECONDS, 'nowera_capi_audit_backfill', array( $next, 1 ), 'nowera-capi' );
	} elseif ( false === $next && (int) $attempt < 8 ) {
		// The gateway did not take a page: the same page again, later each time.
		as_schedule_single_action( time() + (int) $attempt * 15 * MINUTE_IN_SECONDS, 'nowera_capi_audit_backfill', array( $page, (int) $attempt + 1 ), 'nowera-capi' );
	}
}, 10, 2 );

/**
 * The bookings one request did not hold, 500 at a time: marked as a part, so
 * the gateway does not take the request for a list of orders. A request that
 * fails ends the chain; the next hourly list starts it again.
 */
add_action( 'nowera_capi_bookings_more', function ( $since, $offset ) {
	$rows = nowera_capi_ledger_bookings( (int) $since, (int) $offset );
	if ( ! $rows ) {
		return;
	}
	$tz   = wp_timezone();
	$body = wp_json_encode( array(
		'day'      => ( new \DateTimeImmutable( 'now', $tz ) )->format( 'Y-m-d' ),
		'timezone' => $tz->getName(),
		'page'     => 1,
		'pages'    => 1,
		'partial'  => true,
		'orders'   => array(),
		'bookings' => $rows,
	) );
	if ( null === nowera_capi_deliver( $body, '/r', 15 ) && 500 === count( $rows ) && function_exists( 'as_schedule_single_action' ) ) {
		as_schedule_single_action( time() + MINUTE_IN_SECONDS, 'nowera_capi_bookings_more', array( (int) $since, (int) $offset + 500 ), 'nowera-capi' );
	}
}, 10, 2 );

/**
 * Sends the orders changed in the last `$days` days; true when every page went
 * through, false when the gateway did not take one. With a time budget (seconds)
 * it stops when that is spent and returns the page to go on from.
 */
function nowera_capi_send_audit( int $days = 3, int $from_page = 1, int $budget = 0 ) {
	$tz      = wp_timezone();
	$today   = ( new \DateTimeImmutable( 'now', $tz ) )->format( 'Y-m-d' );
	$since   = time() - $days * DAY_IN_SECONDS;
	$started = microtime( true );
	$per     = 200;
	$page    = $from_page;
	$pages   = 1;
	do {
		$found = wc_get_orders( array(
			'type'          => 'shop_order',
			'limit'         => $per,
			'paged'         => $page,
			'paginate'      => true,
			'return'        => 'ids',
			'orderby'       => 'ID',
			'order'         => 'ASC',
			'status'        => array_keys( wc_get_order_statuses() ),
			'date_modified' => '>=' . $since,
		) );
		$pages = max( 1, (int) $found->max_num_pages );
		$lines = array();
		foreach ( $found->orders as $id ) {
			$order = wc_get_order( $id );
			if ( $order instanceof \WC_Order ) {
				$lines[] = nowera_capi_audit_line( $order, $tz );
			}
		}
		$body = wp_json_encode( array(
			'day'      => $today,
			'timezone' => $tz->getName(),
			'page'     => $page,
			'pages'    => $pages,
			'total'    => (int) $found->total,
			'cron'     => $from_page === $page ? nowera_capi_cron_report() : null,
			'orders'   => $lines,
			// Bookings as the booking plugin holds them, the ones made by staff
			// included (no order ever exists for those). No contact data either.
			'bookings' => 1 === $page ? nowera_capi_ledger_bookings( $since ) : null,
		) );
		$first = 1 === $page;
		if ( null !== nowera_capi_deliver( $body, '/r', 15 ) ) {
			return false; // the next run sends it all again
		}
		// More bookings than one request holds: the rest follow on their own, one
		// request a minute (see nowera_capi_bookings_more).
		if ( $first && 500 === count( nowera_capi_ledger_bookings( $since ) ) && function_exists( 'as_schedule_single_action' )
			&& ! as_has_scheduled_action( 'nowera_capi_bookings_more', null, 'nowera-capi' ) ) {
			as_schedule_single_action( time() + MINUTE_IN_SECONDS, 'nowera_capi_bookings_more', array( $since, 500 ), 'nowera-capi' );
		}
		$page++;
		if ( $budget && $page <= $pages && microtime( true ) - $started > $budget ) {
			return $page;
		}
	} while ( $page <= $pages );
	return true;
}

/**
 * How the site's scheduler is doing: WP-Cron switched off, and the plugin's
 * tasks waiting past their time (a fallback purchase, a retry).
 */
function nowera_capi_cron_report(): array {
	global $wpdb;
	$due    = 0;
	$oldest = 0;
	$table  = $wpdb->prefix . 'actionscheduler_actions';
	if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table ) {
		$row = $wpdb->get_row( $wpdb->prepare(
			"SELECT COUNT(*) AS n, MIN(a.scheduled_date_gmt) AS first FROM {$table} a
			   JOIN {$wpdb->prefix}actionscheduler_groups g ON g.group_id = a.group_id
			  WHERE g.slug = %s AND a.status = 'pending' AND a.scheduled_date_gmt < %s",
			'nowera-capi',
			gmdate( 'Y-m-d H:i:s', time() - 15 * MINUTE_IN_SECONDS )
		) );
		$due    = (int) ( $row->n ?? 0 );
		$oldest = $due && ! empty( $row->first ) ? max( 0, time() - strtotime( $row->first . ' UTC' ) ) : 0;
	}
	return array(
		'disabled' => defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON,
		'due'      => $due,
		'oldest'   => $oldest,
	);
}

/**
 * Bookings made since `$since` or still to take place (those can still change),
 * from whichever booking plugin an adapter reads: id, source (web or staff),
 * type, what was booked, status, when it takes place, its price and the order
 * it belongs to. 500 at a time, from `$offset`.
 */
function nowera_capi_ledger_bookings( int $since, int $offset = 0 ): array {
	static $cache = array();
	$key = $since . ':' . $offset;
	if ( ! isset( $cache[ $key ] ) ) {
		$rows          = apply_filters( 'nowera_capi_ledger_bookings', array(), $since, $offset );
		$cache[ $key ] = is_array( $rows ) ? array_slice( array_values( $rows ), 0, 500 ) : array();
	}
	return $cache[ $key ];
}

/** One order as the completeness check sees it. */
function nowera_capi_audit_line( \WC_Order $order, ?\DateTimeZone $tz = null ): array {
	$created = $order->get_date_created();
	$paid    = $order->get_date_paid();
	$consent = (string) $order->get_meta( '_nowera_capi_purchase_consent' );
	$plan    = nowera_capi_order_plan( $order );
	// What was sent stands, whatever the order looks like now; an order reported
	// before plans existed was reported as a Purchase.
	$reported = nowera_capi_reported_plan( $order );
	$expect   = $reported ? $reported['expect'] : ( $order->get_meta( '_nowera_capi_purchase_sent' ) ? array( 'Purchase' ) : $plan['expect'] );
	return array(
		'kind'     => $plan['kind'],
		'expect'   => array_values( $expect ),
		'goods'    => $plan['goods'],
		'tender'   => $plan['tender'],
		'parts'    => (object) $plan['parts'],
		'bookings' => $plan['lead']['count'] ?? 0,
		'refunded' => round( (float) $order->get_total_refunded(), wc_get_price_decimals() ),
		'id'       => $order->get_id(),
		'day'      => $created ? ( new \DateTimeImmutable( '@' . $created->getTimestamp() ) )->setTimezone( $tz ?: wp_timezone() )->format( 'Y-m-d' ) : null,
		'created'  => $created ? $created->getTimestamp() : null,
		'paid'     => $paid ? $paid->getTimestamp() : null,
		'status'   => $order->get_status(),
		'total'    => (float) $order->get_total(),
		'currency' => $order->get_currency(),
		'ready'    => nowera_capi_purchase_ready( $order ),
		'consent'  => in_array( $consent, array( 'marketing', 'statistics', 'none' ), true ) ? $consent : '',
		'ctx'      => (bool) $order->get_meta( '_nowera_capi_ctx' ),
		'sent'     => (bool) $order->get_meta( '_nowera_capi_purchase_sent' ),
		'thankyou' => (bool) $order->get_meta( '_nowera_capi_thankyou' ),
		'via'      => (string) $order->get_created_via(),
	);
}

/* -------------------------------------------------------------------------
 * WooCommerce events
 * ---------------------------------------------------------------------- */

add_action( 'woocommerce_thankyou', 'nowera_capi_thankyou', 10, 1 );

/**
 * A thank-you page built by a page builder from its own parts may never run
 * WooCommerce's woocommerce_thankyou hook, and then the purchase left only 30
 * minutes after the payment, from the server alone. On the order-received page
 * the plugin checks before the footer whether the hook ran, and if not, does
 * its part itself — for the order the address names and only with its key,
 * exactly as WooCommerce itself decides whose thank-you page it is.
 */
add_action( 'wp_footer', function () {
	if ( did_action( 'woocommerce_thankyou' ) || ! function_exists( 'is_order_received_page' ) || ! is_order_received_page() ) {
		return;
	}
	global $wp;
	$order_id = absint( $wp->query_vars['order-received'] ?? 0 );
	$key      = isset( $_GET['key'] ) && is_string( $_GET['key'] ) ? wc_clean( wp_unslash( $_GET['key'] ) ) : '';
	$order    = $order_id ? wc_get_order( $order_id ) : null;
	if ( ! $order instanceof \WC_Order || '' === $key || ! hash_equals( $order->get_order_key(), $key ) ) {
		return;
	}
	// WooCommerce shows the order only to its own customer, logged in, and asks
	// anyone it cannot recognise to confirm the e-mail first. Someone else holding
	// the link sees a login or e-mail form, and that is no thank-you page.
	$customer = $order->get_customer_id();
	if ( $customer && apply_filters( 'woocommerce_order_received_verify_known_shoppers', true ) && get_current_user_id() !== $customer ) {
		return;
	}
	$users = '\\Automattic\\WooCommerce\\Internal\\Utilities\\Users';
	if ( class_exists( $users ) && method_exists( $users, 'should_user_verify_order_email' )
		&& $users::should_user_verify_order_email( $order_id, null, 'order-received' ) ) {
		return;
	}
	nowera_capi_thankyou( $order_id );
}, 1 );

function nowera_capi_thankyou( $order_id ): void {
	$order = wc_get_order( $order_id );
	if ( ! $order ) {
		return;
	}
	// WooCommerce shows this page for a failed or still unpaid order too. Such an
	// order is reported once its payment is confirmed (see the fallback below);
	// no tag on this page reported it, so that report is the only copy.
	if ( ! nowera_capi_purchase_ready( $order ) ) {
		if ( ! $order->get_meta( '_nowera_capi_thankyou_unpaid' ) ) {
			$order->update_meta_data( '_nowera_capi_thankyou_unpaid', time() );
			$order->save_meta_data();
		}
		return;
	}
	// The page loaded for a real purchase, so the site's own tags (GTM, gtag) had
	// their chance to report it; a later retry is no longer the only copy.
	if ( ! $order->get_meta( '_nowera_capi_thankyou' ) ) {
		$order->update_meta_data( '_nowera_capi_thankyou', time() );
		$order->save_meta_data();
	}
	// The thank-you page is refreshed and bookmarked; send Purchase exactly once.
	if ( $order->get_meta( '_nowera_capi_purchase_sent' ) ) {
		return;
	}

	// A Lead for bookings, a Purchase for goods, as the order's plan says; each
	// with its browser half under the same id.
	$outcome = nowera_capi_report_order( $order, nowera_capi_user_from_order( $order ), null, true );

	nowera_capi_record_outcome( $order, $outcome );
	// Only a delivered event closes the order for good. Without consent the
	// visitor may still accept the banner on this very page, and then a reload
	// (or the browser leg waiting in the loader) still reports the purchase.
	if ( 'marketing' === $outcome || 'statistics' === $outcome ) {
		$order->update_meta_data( '_nowera_capi_purchase_sent', time() );
		// Reported from the page: the payment confirmation has nothing left to do.
		if ( function_exists( 'as_unschedule_action' ) ) {
			as_unschedule_action( 'nowera_capi_purchase_fallback', array( (int) $order->get_id() ), 'nowera-capi' );
		}
	}
	$order->save();
}

/**
 * The thank-you page's address without its query string: the order key in it
 * opens the order, and must not travel to Meta or Google.
 */
function nowera_capi_order_url( \WC_Order $order ): string {
	return strtok( $order->get_checkout_order_received_url(), '?' );
}

/**
 * Whether an order counts as a purchase yet. Paid orders do, and so do orders
 * paid on delivery or by bank transfer (processing or on-hold) — those are
 * counted when placed and taken back with a refund if cancelled. Failed,
 * cancelled and still unpaid orders do not.
 */
function nowera_capi_purchase_ready( \WC_Order $order ): bool {
	$ready = ! $order->has_status( array( 'failed', 'cancelled', 'pending', 'checkout-draft', 'refunded', 'trash' ) );
	return (bool) apply_filters( 'nowera_capi_purchase_ready', $ready, $order );
}

/**
 * A paid order whose buyer never came back to the thank-you page (common with
 * 24pay's redirect) would never be reported. Wait half an hour first: if the
 * thank-you page does load, it reports the purchase with fresher consent.
 */
function nowera_capi_schedule_purchase_fallback( $order_id ): void {
	$order = wc_get_order( $order_id );
	if ( ! $order || ! function_exists( 'as_schedule_single_action' ) ) {
		return;
	}
	if ( $order->get_meta( '_nowera_capi_purchase_sent' ) || $order->get_meta( '_nowera_capi_purchase_consent' ) || ! $order->get_meta( '_nowera_capi_ctx' ) ) {
		return; // already reported, already decided, or never went through our checkout
	}
	$args = array( (int) $order->get_id() );
	// The thank-you page already came and went (the order was not paid yet then):
	// nothing to wait for any more.
	$delay = $order->get_meta( '_nowera_capi_thankyou_unpaid' ) ? MINUTE_IN_SECONDS : 30 * MINUTE_IN_SECONDS;
	if ( ! as_next_scheduled_action( 'nowera_capi_purchase_fallback', $args, 'nowera-capi' ) ) {
		as_schedule_single_action( time() + $delay, 'nowera_capi_purchase_fallback', $args, 'nowera-capi' );
	}
}
add_action( 'woocommerce_payment_complete', 'nowera_capi_schedule_purchase_fallback' );
add_action( 'woocommerce_order_status_on-hold', 'nowera_capi_schedule_purchase_fallback' );
add_action( 'woocommerce_order_status_processing', 'nowera_capi_schedule_purchase_fallback' );
add_action( 'woocommerce_order_status_completed', 'nowera_capi_schedule_purchase_fallback' );

add_action( 'nowera_capi_purchase_fallback', function ( $order_id ) {
	$order = wc_get_order( $order_id );
	if ( ! $order || $order->get_meta( '_nowera_capi_purchase_sent' ) ) {
		return; // reported already
	}
	if ( ! nowera_capi_purchase_ready( $order ) ) {
		return; // a later payment confirmation schedules this again
	}
	// The thank-you page decided (e.g. no consent) — unless its delivery failed and this is the retry.
	$retry = (int) $order->get_meta( '_nowera_capi_purchase_retry' ) > 0;
	if ( ! $retry && $order->get_meta( '_nowera_capi_purchase_consent' ) ) {
		return;
	}
	$stored = $order->get_meta( '_nowera_capi_ctx' );
	if ( ! is_array( $stored ) ) {
		return;
	}

	// Consent and identifiers as they were at checkout; address and browser as
	// WooCommerce stored them with the order; the time of the payment itself.
	$paid = $order->get_date_paid() ?: $order->get_date_created();
	$ctx  = array(
		'marketing'     => ! empty( $stored['marketing'] ),
		'statistics'    => ! empty( $stored['statistics'] ),
		'fbp'           => $stored['fbp'] ?? null,
		'fbc'           => $stored['fbc'] ?? null,
		'fbclid'        => null,
		'ga_client_id'  => $stored['ga_client_id'] ?? null,
		'ga_session_id' => $stored['ga_session_id'] ?? null,
		'ip'            => (string) $order->get_customer_ip_address(),
		'ua'            => (string) $order->get_customer_user_agent(),
		'event_time'    => $paid ? $paid->getTimestamp() : time(),
		'referrer_url'  => null,
		'browserless'   => ! $order->get_meta( '_nowera_capi_thankyou' ),
	);
	$user = nowera_capi_user_from_order( $order );
	if ( ! $order->get_customer_id() && ! empty( $stored['visitor'] ) ) {
		$user['external_id'] = (string) $stored['visitor']; // no visitor cookie in this request
	}

	$outcome = nowera_capi_report_order( $order, $user, $ctx );
	if ( ! $retry ) {
		nowera_capi_record_outcome( $order, $outcome, true );
	}
	if ( 'marketing' === $outcome || 'statistics' === $outcome ) {
		$order->update_meta_data( '_nowera_capi_purchase_sent', time() );
	}
	$order->save();
} );

/** The AddToCart this request sent, for the browser to report under the same id. */
function nowera_capi_atc_leg( ?array $leg = null ): ?array {
	static $current = null;
	if ( null !== $leg ) {
		$current = $leg;
	}
	return $current;
}

/** AddToCart for a cart line that just got $quantity more, from the server and for the browser. */
function nowera_capi_added( int $product_id, int $quantity, int $variation_id = 0 ): void {
	$product = wc_get_product( $variation_id ?: $product_id );
	if ( ! $product ) {
		return;
	}
	$item        = nowera_capi_item( $product, (int) $quantity );
	$event_id    = wp_generate_uuid4();
	$custom_data = array(
		'value'        => round( $item['item_price'] * (int) $quantity, wc_get_price_decimals() ),
		'value_net'    => round( $item['price_net'] * (int) $quantity, wc_get_price_decimals() ),
		'currency'     => get_woocommerce_currency(),
		'content_ids'  => array( $item['id'] ),
		'contents'     => array( $item ),
		'content_name' => $product->get_name(),
		'content_type' => 'product',
	);
	nowera_capi_send( 'AddToCart', $event_id, nowera_capi_current_user(), $custom_data, get_permalink( $product_id ) );

	// The browser half: an AJAX add to cart hands it over in the cart fragments;
	// a plain form post shows it on the next page this visitor loads; a Store API
	// add (block buttons, custom buy boxes) parks it for px.js to fetch.
	nowera_capi_atc_leg( array( 'event_id' => $event_id, 'data' => $custom_data ) );
	if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
		nowera_capi_park_leg( array( 'AddToCart', $event_id, $custom_data ) );
	} elseif ( ! wp_doing_ajax() && WC()->session ) {
		$pending   = (array) WC()->session->get( 'nowera_capi_legs', array() );
		$pending[] = array( 'AddToCart', $event_id, $custom_data );
		WC()->session->set( 'nowera_capi_legs', array_slice( $pending, -5 ) );
	}
}

/**
 * Cart lines whose added quantity the Store API hook below has reported in this
 * request. Should a plugin then add the same line the classic way, its
 * woocommerce_add_to_cart (which follows the quantity change) is that same add.
 */
function nowera_capi_reported_line( string $key, ?bool $mark = null ): bool {
	static $lines = array();
	if ( '' === $key ) {
		$lines = array(); // a new REST request (or the next one in a batch)
		return false;
	}
	$was = isset( $lines[ $key ] );
	if ( true === $mark ) {
		$lines[ $key ] = true;
	} elseif ( false === $mark ) {
		unset( $lines[ $key ] );
	}
	return $was;
}

add_action( 'woocommerce_add_to_cart', function ( $cart_item_key, $product_id, $quantity, $variation_id = 0 ) {
	if ( nowera_capi_reported_line( (string) $cart_item_key, false ) ) {
		return;
	}
	nowera_capi_added( (int) $product_id, (int) $quantity, (int) $variation_id );
}, 10, 4 );

/** The REST route being handled, each request of a Store API batch included. */
function nowera_capi_rest_route( ?string $route = null ): string {
	static $current = '';
	if ( null !== $route ) {
		$current = $route;
	}
	return $current;
}
add_filter( 'rest_request_before_callbacks', function ( $response, $handler, $request ) {
	nowera_capi_rest_route( $request instanceof \WP_REST_Request ? (string) $request->get_route() : '' );
	nowera_capi_reported_line( '' );
	return $response;
}, 10, 3 );

// The Store API adds a product already in the cart by raising that line's
// quantity, without woocommerce_add_to_cart. Raising it on the cart page is no
// add to cart (nor is it in the classic cart), so only cart/add-item counts.
add_action( 'woocommerce_after_cart_item_quantity_update', function ( $key, $quantity, $old_quantity, $cart ) {
	if ( (int) $quantity <= (int) $old_quantity || ! preg_match( '#^/wc/store(/v\d+)?/cart/add-item$#', nowera_capi_rest_route() ) ) {
		return;
	}
	$line = $cart->get_cart_item( $key );
	if ( ! empty( $line['product_id'] ) ) {
		nowera_capi_reported_line( (string) $key, true );
		nowera_capi_added( (int) $line['product_id'], (int) $quantity - (int) $old_quantity, (int) ( $line['variation_id'] ?? 0 ) );
	}
}, 10, 4 );

/**
 * Where a Store API add to cart parks its browser leg: beside the visitor's
 * WooCommerce session, not in it. Taking it out of the session would save the
 * whole session again, and a request that read it before a cart change
 * running at the same time would put the old cart back.
 */
function nowera_capi_parked_key(): ?string {
	if ( ! function_exists( 'WC' ) || ! WC()->session ) {
		return null;
	}
	$customer = (string) WC()->session->get_customer_id();
	return '' === $customer ? null : 'nowera_capi_legs_' . md5( $customer );
}

function nowera_capi_park_leg( array $leg ): void {
	$key = nowera_capi_parked_key();
	if ( ! $key ) {
		return;
	}
	$parked   = get_transient( $key );
	$parked   = is_array( $parked ) ? $parked : array();
	$parked[] = $leg;
	set_transient( $key, array_slice( $parked, -5 ), HOUR_IN_SECONDS );
	// So later pages know to look (and pages of everyone else need not): this
	// request saves the session anyway, with the cart it has just changed.
	if ( ! WC()->session->get( 'nowera_capi_parked' ) ) {
		WC()->session->set( 'nowera_capi_parked', 1 );
	}
}

/** The parked legs, handed out once. */
function nowera_capi_take_parked(): array {
	$key    = nowera_capi_parked_key();
	$parked = $key ? get_transient( $key ) : false;
	if ( ! is_array( $parked ) || ! $parked ) {
		return array();
	}
	delete_transient( $key );
	return $parked;
}

// A string, not an object: themes loop over fragments expecting HTML strings.
add_filter( 'woocommerce_add_to_cart_fragments', function ( $fragments ) {
	$leg = nowera_capi_atc_leg();
	if ( $leg && is_array( $fragments ) ) {
		$fragments['nwr_atc'] = wp_json_encode( $leg );
	}
	return $fragments;
} );

/** Browser legs waiting since a plain add-to-cart form post or a Store API add. Such a page belongs to one visitor: never cached. */
function nowera_capi_pending_legs(): void {
	if ( ! function_exists( 'WC' ) || ! WC()->session || wp_doing_ajax() ) {
		return;
	}
	$pending = WC()->session->get( 'nowera_capi_legs' );
	$parked  = WC()->session->get( 'nowera_capi_parked' );
	if ( ! $pending && ! $parked ) {
		return;
	}
	$pending = is_array( $pending ) ? $pending : array();
	if ( $pending ) {
		WC()->session->set( 'nowera_capi_legs', null );
	}
	if ( $parked ) {
		// A Store API add px.js did not pick up (it never asked, or the visitor left
		// first). The flag stays: clearing it would write the session (see
		// nowera_capi_parked_key), and looking costs one transient read.
		$pending = array_merge( $pending, nowera_capi_take_parked() );
	}
	if ( ! $pending ) {
		return;
	}
	if ( ! defined( 'DONOTCACHEPAGE' ) ) {
		define( 'DONOTCACHEPAGE', true );
	}
	do_action( 'litespeed_control_set_nocache', 'nowera-capi: browser event for this visitor' );
	nocache_headers();
	foreach ( $pending as $leg ) {
		if ( is_array( $leg ) && 3 === count( $leg ) ) {
			nowera_capi_browser_leg( (string) $leg[0], (string) $leg[1], (array) $leg[2] );
		}
	}
}
add_action( 'template_redirect', 'nowera_capi_pending_legs', 6 );

// The AJAX half is picked up by px.js, which WooCommerce's added_to_cart hands the
// fragments to; px.js comes fresh from the gateway even on pages cached long ago.

/**
 * ?wc-ajax=nwr_legs: hands px.js the legs a Store API add to cart parked for this
 * visitor and forgets them, so each fires once, from here or from the next page.
 * POST only (prefetchers and caches never take them), never cached, a request
 * another site's page makes is answered with nothing, and the session itself is
 * never written (see nowera_capi_parked_key).
 */
function nowera_capi_legs_endpoint(): void {
	if ( ! defined( 'DONOTCACHEPAGE' ) ) {
		define( 'DONOTCACHEPAGE', true );
	}
	do_action( 'litespeed_control_set_nocache', 'nowera-capi: browser events for this visitor' );
	nocache_headers();
	header( 'X-Robots-Tag: noindex' );

	$legs = array();
	$site = strtolower( (string) ( $_SERVER['HTTP_SEC_FETCH_SITE'] ?? '' ) );
	if ( 'POST' === ( $_SERVER['REQUEST_METHOD'] ?? '' ) && 'cross-site' !== $site ) {
		foreach ( nowera_capi_take_parked() as $leg ) {
			if ( is_array( $leg ) && 3 === count( $leg ) ) {
				$legs[] = array( 'event' => (string) $leg[0], 'event_id' => (string) $leg[1], 'data' => (array) $leg[2] );
			}
		}
	}
	wp_send_json( array( 'legs' => $legs ) );
}
add_action( 'wc_ajax_nwr_legs', 'nowera_capi_legs_endpoint' );

/**
 * InitiateCheckout when the checkout page opens, classic or built from blocks.
 * Once per cart: reloading the checkout or coming back from the payment page
 * is not a new checkout.
 */
function nowera_capi_maybe_initiate_checkout(): void {
	if ( ! function_exists( 'is_checkout' ) || ! is_checkout() || is_order_received_page()
		|| ( function_exists( 'is_checkout_pay_page' ) && is_checkout_pay_page() ) ) {
		return;
	}
	if ( ! WC()->cart || WC()->cart->is_empty() ) {
		return;
	}
	$hash = WC()->cart->get_cart_hash();
	$seen = WC()->session ? WC()->session->get( 'nowera_capi_ic' ) : null;
	if ( is_array( $seen ) && ( $seen['hash'] ?? '' ) === $hash && (int) ( $seen['at'] ?? 0 ) > time() - HOUR_IN_SECONDS ) {
		return;
	}
	$items       = nowera_capi_cart_items();
	$event_id    = wp_generate_uuid4();
	$custom_data = array(
		'value'        => (float) WC()->cart->get_total( 'edit' ),
		'value_net'    => round( (float) WC()->cart->get_subtotal() - (float) WC()->cart->get_discount_total(), wc_get_price_decimals() ),
		'currency'     => get_woocommerce_currency(),
		'num_items'    => WC()->cart->get_cart_contents_count(),
		'content_ids'  => array_values( array_unique( array_column( $items, 'id' ) ) ),
		'contents'     => $items,
		'content_type' => 'product',
	);
	$coupons = WC()->cart->get_applied_coupons();
	if ( $coupons ) {
		$custom_data['coupon'] = implode( ',', $coupons );
	}

	nowera_capi_send( 'InitiateCheckout', $event_id, nowera_capi_current_user(), $custom_data, wc_get_checkout_url() );
	// The checkout page is never cached, so the browser leg can share this id.
	nowera_capi_browser_leg( 'InitiateCheckout', $event_id, $custom_data );
	if ( WC()->session ) {
		WC()->session->set( 'nowera_capi_ic', array( 'hash' => $hash, 'at' => time() ) );
	}
}
add_action( 'template_redirect', 'nowera_capi_maybe_initiate_checkout', 20 );

/**
 * A refund, partial or full, made in the administration or by the payment
 * gateway. No browser sees it, so it goes from here, marked as browserless: GA4
 * subtracts it from the purchase it recorded under the same transaction id. Only
 * for orders whose buyer allowed statistics at checkout, the ones GA4 can have
 * counted; Meta has no refund event and the gateway does not pass it there.
 */
function nowera_capi_refund( $order_id, $refund_id ): void {
	$order  = wc_get_order( $order_id );
	$refund = wc_get_order( $refund_id );
	if ( ! $order || ! $refund instanceof \WC_Order_Refund ) {
		return;
	}
	$stored = $order->get_meta( '_nowera_capi_ctx' );
	$stored = is_array( $stored ) ? $stored : array();
	// Only what GA4 counted can be taken back: a Purchase reported (with consent,
	// at checkout or later on the thank-you page) or consent stored at checkout.
	if ( ! $order->get_meta( '_nowera_capi_purchase_sent' ) && empty( $stored['statistics'] ) ) {
		return;
	}
	// A cancellation already took back everything that was left.
	if ( $order->get_meta( '_nowera_capi_cancel_sent' ) ) {
		return;
	}
	// A booking was a Lead and an order that cost nothing was reported to nobody:
	// GA4 holds no purchase to take back. Of an order that was part booking, part
	// goods, only the goods' share of the money returned is taken back.
	$plan  = nowera_capi_refund_plan( $order );
	$share = 1.0;
	$split = false;
	if ( $plan ) {
		if ( ! in_array( 'Purchase', $plan['expect'], true ) ) {
			return;
		}
		$share = max( 0.0, min( 1.0, (float) ( $plan['share'] ?? 1.0 ) ) );
		$split = ! empty( $plan['split'] );
	}

	$contents = array();
	foreach ( $refund->get_items() as $item ) {
		// Lines keep their full prices; a purchase reported in part has none to match.
		if ( ! $split && $item instanceof \WC_Order_Item_Product && abs( (int) $item->get_quantity() ) ) {
			$contents[] = nowera_capi_order_item( $item, $refund );
		}
	}
	$returned = abs( (float) $refund->get_amount() );
	$amount   = round( $returned * $share, wc_get_price_decimals() );
	if ( $split ) {
		// What was given back line by line says which part it was: a booking's
		// line takes nothing from the purchase, the goods' lines all of theirs —
		// each at the share that was paid in money, as it was counted.
		$cash   = max( 0.0, min( 1.0, (float) ( $plan['cash'] ?? 1.0 ) ) );
		$leads  = nowera_capi_lead_kinds();
		$lines  = false;
		$gross  = 0.0;
		$net    = 0.0;
		foreach ( $refund->get_items( array( 'line_item', 'shipping', 'fee' ) ) as $item ) {
			$lines = true;
			if ( $item instanceof \WC_Order_Item_Product ) {
				// A line the Purchase did not cover (a booking reported as a lead only;
				// plans from before 1.3.2 do not say, and covered no booking) gives nothing back.
				$kind = nowera_capi_line_kind( $item, $order );
				if ( isset( $plan['sold'] ) ? ! in_array( $kind, (array) $plan['sold'], true ) : in_array( $kind, $leads, true ) ) {
					continue;
				}
				$net += abs( (float) $item->get_total() );
			}
			$gross += abs( (float) $item->get_total() ) + abs( (float) $item->get_total_tax() );
		}
		if ( $lines ) {
			$amount = round( $gross * $cash, wc_get_price_decimals() );
			$net   *= $cash;
		} else {
			// An amount without lines: the purchase's share of it.
			$total = (float) $order->get_total();
			$net   = $total > 0 ? $returned * (float) ( $plan['net'] ?? 0 ) / $total : 0.0;
		}
		// Never more than the purchase was reported for, whatever mix of amounts
		// and lines the refunds come in.
		$reported = round( (float) $order->get_total() * $share, wc_get_price_decimals() );
		$amount   = min( $amount, max( 0.0, $reported - (float) $order->get_meta( '_nowera_capi_refunded_value' ) ) );
		$net      = min( $net, max( 0.0, (float) ( $plan['net'] ?? 0 ) - (float) $order->get_meta( '_nowera_capi_refunded_net' ) ) );
		if ( $amount <= 0 ) {
			return; // only the booking was given back, or nothing of the purchase is left
		}
	} elseif ( $contents ) {
		$net = array_sum( array_map( function ( $i ) { return $i['price_net'] * $i['quantity']; }, $contents ) );
	} elseif ( $refund->get_items( array( 'shipping', 'fee', 'tax' ) ) ) {
		// No products, only shipping, fees or tax given back: no item revenue.
		$net = max( 0, $amount - abs( (float) $refund->get_total_tax() ) - abs( (float) $refund->get_shipping_total() ) );
	} else {
		$net = nowera_capi_net_share( $order, $amount ); // an amount without lines
	}
	$net = round( $net, wc_get_price_decimals() );
	$props  = array(
		'order_id'  => $order->get_id(),
		'value'     => $amount,
		'value_net' => $net,
		'currency'  => $order->get_currency(),
	);
	// What GA4 has been told back so far, so a later cancellation takes only the rest.
	$order->update_meta_data( '_nowera_capi_refunded_net', round( (float) $order->get_meta( '_nowera_capi_refunded_net' ) + $net, wc_get_price_decimals() ) );
	$order->update_meta_data( '_nowera_capi_refunded_value', round( (float) $order->get_meta( '_nowera_capi_refunded_value' ) + $amount, wc_get_price_decimals() ) );
	$order->save_meta_data();
	// Without items GA4 takes it as a refund of the whole order.
	if ( $contents ) {
		$props['contents'] = $contents;
	}

	nowera_capi_send( 'Refund', 'refund-' . $refund->get_id(), array(), $props, nowera_capi_order_url( $order ), array(
		'marketing'     => ! empty( $stored['marketing'] ),
		'statistics'    => true,
		'fbp'           => null,
		'fbc'           => null,
		'fbclid'        => null,
		'ga_client_id'  => $stored['ga_client_id'] ?? null, // the buyer, as GA4 knows them
		'ga_session_id' => null,
		'ip'            => (string) $order->get_customer_ip_address(),
		'ua'            => (string) $order->get_customer_user_agent(),
		'event_time'    => time(),
		'referrer_url'  => null,
		'browserless'   => true,
	) );
}
add_action( 'woocommerce_order_refunded', 'nowera_capi_refund', 10, 2 );

/**
 * An order counted as a purchase and then cancelled without a refund (a bank
 * transfer never paid, a parcel on delivery refused): GA4 takes the rest of its
 * value back, as a refund of the whole order.
 */
function nowera_capi_cancelled( $order_id ): void {
	$order = wc_get_order( $order_id );
	if ( ! $order || ! $order->get_meta( '_nowera_capi_purchase_sent' ) || $order->get_meta( '_nowera_capi_cancel_sent' ) ) {
		return;
	}
	$stored = $order->get_meta( '_nowera_capi_ctx' );
	$stored = is_array( $stored ) ? $stored : array();
	$plan  = nowera_capi_refund_plan( $order );
	$share = 1.0;
	if ( $plan ) {
		if ( ! in_array( 'Purchase', $plan['expect'], true ) ) {
			return; // a Lead or nothing was reported: GA4 holds no purchase to take back
		}
		$share = max( 0.0, min( 1.0, (float) ( $plan['share'] ?? 1.0 ) ) );
	}
	$left = round( ( (float) $order->get_total() - (float) $order->get_total_refunded() ) * $share, wc_get_price_decimals() );
	if ( $plan && ! empty( $plan['split'] ) ) {
		// Part of the order was a purchase: what of that part is not yet taken back.
		$left = round( (float) $order->get_total() * $share - (float) $order->get_meta( '_nowera_capi_refunded_value' ), wc_get_price_decimals() );
	}
	if ( $left <= 0 ) {
		return;
	}
	$outcome = nowera_capi_send( 'Refund', 'cancel-' . $order->get_id(), array(), array(
		'order_id'  => $order->get_id(),
		'value'     => $left,
		'value_net' => max( 0, round( (float) ( $plan['net'] ?? nowera_capi_order_net( $order ) ) - (float) $order->get_meta( '_nowera_capi_refunded_net' ), wc_get_price_decimals() ) ),
		'currency'  => $order->get_currency(),
	), nowera_capi_order_url( $order ), array(
		'marketing'     => ! empty( $stored['marketing'] ),
		'statistics'    => true,
		'fbp'           => null,
		'fbc'           => null,
		'fbclid'        => null,
		'ga_client_id'  => $stored['ga_client_id'] ?? null,
		'ga_session_id' => null,
		'ip'            => (string) $order->get_customer_ip_address(),
		'ua'            => (string) $order->get_customer_user_agent(),
		'event_time'    => time(),
		'referrer_url'  => null,
		'browserless'   => true,
	) );
	if ( 'none' !== $outcome && 'not_configured' !== $outcome ) {
		$order->update_meta_data( '_nowera_capi_cancel_sent', time() );
		$order->add_order_note( 'Nowera CAPI: objednávka zrušená, GA4 dostal refund celej sumy.' );
		$order->save();
	}
}
add_action( 'woocommerce_order_status_cancelled', 'nowera_capi_cancelled' );
add_action( 'woocommerce_order_status_failed', 'nowera_capi_cancelled' );

/**
 * Best identity available before an order exists. Most checkouts are guests, so
 * falling back to what they typed into the cart/checkout session is what keeps
 * Event Match Quality off the floor.
 */
function nowera_capi_current_user(): array {
	$data = array();

	if ( function_exists( 'WC' ) && WC()->customer ) {
		$customer = WC()->customer;
		$data = array_filter( array(
			'em'      => $customer->get_billing_email(),
			'ph'      => $customer->get_billing_phone(),
			'fn'      => $customer->get_billing_first_name(),
			'ln'      => $customer->get_billing_last_name(),
			'ct'      => $customer->get_billing_city(),
			'zp'      => $customer->get_billing_postcode(),
			'country' => $customer->get_billing_country(),
		) );
	}

	// A signed-in customer: the account's own e-mail and name win, the billing
	// details fill in the phone and address the account does not hold.
	if ( is_user_logged_in() ) {
		$user = wp_get_current_user();
		$data = array_merge( $data, array_filter( array(
			'em'          => $user->user_email,
			'fn'          => $user->first_name,
			'ln'          => $user->last_name,
			'external_id' => (string) $user->ID,
			'account'     => (string) $user->ID,
		) ) );
	}

	// A returning customer: what this session knows wins, the stored identity
	// fills the gaps (usually everything, for a guest who has not typed yet).
	$data = array_merge( nowera_capi_stored_user(), array_filter( $data ) );

	if ( empty( $data['external_id'] ) ) {
		$visitor = nowera_capi_visitor_id();
		if ( $visitor ) {
			$data['external_id'] = $visitor;
		}
	}

	return array_filter( $data );
}

/**
 * AddPaymentInfo when the checkout is submitted and the order exists, just
 * before the customer is sent to pay. It carries the full billing identity, so
 * it is also the strongest match signal before the purchase itself.
 */
function nowera_capi_add_payment_info( $order ): void {
	$order = $order instanceof \WC_Order ? $order : wc_get_order( $order );
	if ( ! $order ) {
		return;
	}
	// The last moment the buyer is certainly on the site: keep what we know.
	nowera_capi_remember_checkout_context( $order );
	if ( $order->get_meta( '_nowera_capi_payment_info_sent' ) ) {
		$order->save_meta_data();
		return;
	}

	$items = nowera_capi_order_items( $order );
	$data  = array(
		'value'        => (float) $order->get_total(),
		'value_net'    => nowera_capi_order_net( $order ),
		'currency'     => $order->get_currency(),
		'content_ids'  => array_values( array_unique( array_column( $items, 'id' ) ) ),
		'contents'     => $items,
		'content_type' => 'product',
		'payment_type' => wp_strip_all_tags( $order->get_payment_method_title() ),
	);
	if ( $order->get_coupon_codes() ) {
		$data['coupon'] = implode( ',', $order->get_coupon_codes() );
	}

	// The shipping choice is final once the order is placed; GA4 gets it as its own
	// funnel step just before the payment one.
	$shipping = $order->get_shipping_methods();
	if ( $shipping ) {
		$tiers = array_map( function ( $line ) { return wp_strip_all_tags( $line->get_method_title() ); }, array_values( $shipping ) );
		nowera_capi_send( 'AddShippingInfo', 'ship-' . $order->get_id(), nowera_capi_user_from_order( $order ),
			array_merge( $data, array( 'shipping_tier' => implode( ', ', array_unique( $tiers ) ) ) ), wc_get_checkout_url() );
	}
	nowera_capi_send( 'AddPaymentInfo', 'pay-' . $order->get_id(), nowera_capi_user_from_order( $order ), $data, wc_get_checkout_url() );

	$order->update_meta_data( '_nowera_capi_payment_info_sent', time() );
	$order->save_meta_data();
}

// Classic checkout passes the id first; the block checkout passes the order.
add_action( 'woocommerce_checkout_order_processed', function ( $order_id, $posted = array(), $order = null ) {
	nowera_capi_add_payment_info( $order ?: $order_id );
}, 20, 3 );
add_action( 'woocommerce_store_api_checkout_order_processed', 'nowera_capi_add_payment_info', 20, 1 );

/* -------------------------------------------------------------------------
 * Connection test
 * ---------------------------------------------------------------------- */

/**
 * A signed, empty event: the gateway checks the signature before the content,
 * so "event_name is required" means host and key are right, and nothing is
 * recorded anywhere.
 */
add_action( 'admin_post_nowera_capi_test', function () {
	if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'nowera_capi_test' ) ) {
		wp_die( 'Nemáte oprávnenie.' );
	}
	$s = nowera_capi_settings();
	$result = array( 'ok' => false, 'message' => 'Najprv vyplňte collector host a kľúč.' );
	if ( $s['collector_host'] && $s['ingest_secret'] ) {
		$timestamp = (string) time();
		$body      = '{}';
		$response  = wp_remote_post( 'https://' . $s['collector_host'] . '/s', array(
			'timeout'     => 8,
			'redirection' => 0,
			'headers'     => array(
				'Content-Type'    => 'application/json',
				'X-NWR-Timestamp' => $timestamp,
				'X-NWR-Signature' => hash_hmac( 'sha256', $timestamp . '.' . $body, $s['ingest_secret'] ),
				'X-NWR-Plugin'    => NOWERA_CAPI_VERSION,
			),
			'body'        => $body,
		) );
		$code = is_wp_error( $response ) ? 0 : (int) wp_remote_retrieve_response_code( $response );
		$text = is_wp_error( $response ) ? $response->get_error_message() : (string) wp_remote_retrieve_body( $response );
		if ( 400 === $code && false !== strpos( $text, 'event_name' ) ) {
			$result = array( 'ok' => true, 'message' => 'Spojenie funguje: gateway odpovedá a prijal podpis tohto webu.' );
			delete_transient( 'nowera_capi_pause' );
		} elseif ( 401 === $code ) {
			$result['message'] = 'Gateway odpovedá, ale kľúč nesedí (' . wp_strip_all_tags( $text ) . '). Vložte nový párovací kód.';
		} elseif ( 404 === $code ) {
			$result['message'] = 'Gateway tento host nepozná. Skontrolujte collector host.';
		} else {
			$result['message'] = 'Gateway neodpovedá: ' . ( $code ? 'HTTP ' . $code : $text );
		}
	}
	set_transient( 'nowera_capi_test_' . get_current_user_id(), $result, MINUTE_IN_SECONDS );
	wp_safe_redirect( admin_url( 'options-general.php?page=nowera-capi' ) );
	exit;
} );

/* -------------------------------------------------------------------------
 * Updates from the gateway, signed
 * ---------------------------------------------------------------------- */

/**
 * The newest release as the gateway describes it, cached for six hours (an hour
 * after a failure). Null when there is none or the gateway cannot be reached.
 */
function nowera_capi_release_info( bool $fresh = false ): ?array {
	$s = nowera_capi_settings();
	if ( empty( $s['collector_host'] ) ) {
		return null;
	}
	$cached = get_site_transient( 'nowera_capi_release' );
	if ( ! $fresh && is_array( $cached ) && array_key_exists( 'info', $cached ) ) {
		return $cached['info'];
	}
	$info     = null;
	$base     = 'https://' . $s['collector_host'] . '/wp/nowera-capi/';
	$response = wp_remote_get( $base . 'info.json', array( 'timeout' => 5, 'redirection' => 0 ) );
	if ( ! is_wp_error( $response ) && 200 === (int) wp_remote_retrieve_response_code( $response ) ) {
		$data = json_decode( (string) wp_remote_retrieve_body( $response ), true );
		// Only a package on the same gateway; its signature is checked before install anyway.
		if ( is_array( $data ) && ! empty( $data['version'] ) && ! empty( $data['signature'] )
			&& is_string( $data['download_url'] ?? null ) && 0 === strpos( $data['download_url'], $base ) ) {
			$info = $data;
		}
	}
	set_site_transient( 'nowera_capi_release', array( 'info' => $info ), $info ? 6 * HOUR_IN_SECONDS : HOUR_IN_SECONDS );
	return $info;
}

/** Whether a release ZIP carries a valid signature by one of the built-in keys. */
function nowera_capi_verify_release( string $zip, string $signature, string $sha256 = '' ): bool {
	if ( '' !== $sha256 && ! hash_equals( strtolower( $sha256 ), hash( 'sha256', $zip ) ) ) {
		return false;
	}
	$sig = base64_decode( $signature, true );
	if ( false === $sig || 64 !== strlen( $sig ) || ! function_exists( 'sodium_crypto_sign_verify_detached' ) ) {
		return false;
	}
	foreach ( NOWERA_CAPI_RELEASE_KEYS as $encoded ) {
		$key = base64_decode( $encoded, true );
		if ( false === $key || 32 !== strlen( $key ) ) {
			continue;
		}
		try {
			if ( sodium_crypto_sign_verify_detached( $sig, $zip, $key ) ) {
				return true;
			}
		} catch ( \Throwable $e ) {
			continue;
		}
	}
	return false;
}

// "Update URI" in the header sends WordPress here instead of wordpress.org.
add_filter( 'update_plugins_signals.nwra.sk', function ( $update, $plugin_data, $plugin_file ) {
	if ( plugin_basename( __FILE__ ) !== $plugin_file ) {
		return $update;
	}
	$info = nowera_capi_release_info();
	if ( ! $info ) {
		return $update;
	}
	return array(
		'slug'         => 'nowera-capi',
		'version'      => $info['version'],
		'url'          => 'https://nowera.sk',
		'package'      => $info['download_url'],
		'requires_php' => $info['requires_php'] ?? '8.0',
		'tested'       => $info['tested'] ?? '',
		'autoupdate'   => ! empty( nowera_capi_settings()['auto_update'] ),
	);
}, 10, 3 );

add_filter( 'plugins_api', function ( $result, $action, $args ) {
	if ( 'plugin_information' !== $action || 'nowera-capi' !== ( $args->slug ?? '' ) ) {
		return $result;
	}
	$info = nowera_capi_release_info();
	return (object) array(
		'name'          => 'Nowera CAPI',
		'slug'          => 'nowera-capi',
		'version'       => $info['version'] ?? NOWERA_CAPI_VERSION,
		'author'        => 'Nowera',
		'homepage'      => 'https://nowera.sk',
		'requires_php'  => $info['requires_php'] ?? '8.0',
		'last_updated'  => $info['released_at'] ?? '',
		'download_link' => $info['download_url'] ?? '',
		'sections'      => array(
			'description' => 'Serverové eventy z WooCommerce do Nowera Gateway (Meta Conversions API a GA4).',
			'changelog'   => nl2br( esc_html( (string) ( $info['notes'] ?? '' ) ) ),
		),
	);
}, 10, 3 );

// On unless the site turned it off, or the gateway paused updates for everyone.
add_filter( 'auto_update_plugin', function ( $update, $item ) {
	if ( plugin_basename( __FILE__ ) !== ( $item->plugin ?? '' ) ) {
		return $update;
	}
	$info = nowera_capi_release_info();
	if ( is_array( $info ) && array_key_exists( 'auto_update', $info ) && false === $info['auto_update'] ) {
		return false;
	}
	return ! empty( nowera_capi_settings()['auto_update'] );
}, 10, 2 );

/**
 * Download our package ourselves and refuse it unless the signature matches a
 * built-in key. WordPress, MainWP and automatic updates all pass through here.
 */
add_filter( 'upgrader_pre_download', function ( $reply, $package, $upgrader = null, $hook_extra = array() ) {
	if ( false !== $reply || ! is_string( $package ) || ! preg_match( '#/wp/nowera-capi/(nowera-capi-[0-9][0-9A-Za-z.-]*\.zip)$#', $package, $m ) ) {
		return $reply;
	}
	$info = nowera_capi_release_info( true );
	if ( ! $info || basename( (string) wp_parse_url( $info['download_url'], PHP_URL_PATH ) ) !== $m[1] ) {
		return new \WP_Error( 'nowera_capi_release', 'Nowera CAPI: toto vydanie gateway neponúka.' );
	}
	if ( ! function_exists( 'download_url' ) ) {
		require_once ABSPATH . 'wp-admin/includes/file.php';
	}
	$file = download_url( $info['download_url'], 60 );
	if ( is_wp_error( $file ) ) {
		return $file;
	}
	if ( ! nowera_capi_verify_release( (string) file_get_contents( $file ), (string) $info['signature'], (string) ( $info['sha256'] ?? '' ) ) ) {
		wp_delete_file( $file );
		return new \WP_Error( 'nowera_capi_signature', 'Nowera CAPI: aktualizácia nemá platný podpis, neinštaluje sa.' );
	}
	return $file;
}, 10, 4 );
